@echo off
chcp 65001 >nul
title Avexa Lume - build
cd /d "%~dp0"
echo.
echo  === Avexa Lume: tek tikla AvexaLume.exe ===
echo.
where node >nul 2>nul || (echo [HATA] Node.js yok. https://nodejs.org adresinden kur, sonra tekrar calistir. & pause & exit /b 1)
where python >nul 2>nul || (echo [HATA] Python yok. https://python.org adresinden kur ^(Add to PATH isaretli^). & pause & exit /b 1)
echo [1/5] Derleyici kuruluyor...
python -m pip install --quiet --disable-pip-version-check ziglang || (echo [HATA] ziglang kurulamadi & pause & exit /b 1)
echo [2/5] Paketler kuruluyor...
call npm install --no-audit --no-fund || (echo [HATA] npm install basarisiz & pause & exit /b 1)
echo [3/5] Motor derleniyor...
call npm run build:core:win || (echo [HATA] Motor derlenemedi. Ekrandaki hatayi Claude'a yapistir. & pause & exit /b 1)
echo [4/5] WinDivert indiriliyor...
call npm run fetch:windivert || (echo [HATA] WinDivert indirilemedi & pause & exit /b 1)
echo [5/5] Kod korunuyor ve EXE paketleniyor...
call npm run protect || (echo [HATA] Kod koruma basarisiz & pause & exit /b 1)
call npx electron-builder --win nsis portable || (echo [HATA] Paketleme basarisiz & pause & exit /b 1)
copy /y "dist\AvexaLume.exe" "AvexaLume.exe" >nul
echo.
echo  TAMAM!
echo   AvexaLume.exe        ^(tek dosya, arkadaslarina bunu gonder^)
echo   dist\AvexaLume-Setup.exe ^(kurulumlu surum^)
echo.
pause
