/*
 * raw_windows.c — ADVANCED (packet-layer) desync backend for Windows.
 *
 * Counterpart of raw_linux.c. Uses WinDivert 2.2 (a signed kernel driver) to
 * intercept the first outbound TLS/HTTP data packet and, by configuration:
 *   - inject a low-TTL / bad-checksum FAKE copy (scrambled SNI) that reaches the
 *     DPI but dies before the server, then re-inject the real packet unchanged;
 *   - sequence-overlap the real first segment (split-seqovl); or
 *   - send it as fakedsplit / fakeddisorder.
 * It also captures INBOUND 80/443 segments to DROP the forged RSTs a censor
 * injects to tear a blocked connection down, and to measure the hop distance to
 * the server from the SYN-ACK TTL for the decoy's TTL.
 *
 * Of outbound UDP it takes only what it acts on, tested in the kernel (see
 * udpdpi.h, "Kernel pre-filters"): a QUIC long header to port 443, and
 * Discord's IP discovery request or a STUN Binding request on the voice ports.
 * A call's own datagrams never come up to this loop, so nothing here can add
 * delay or loss to a call.
 *
 * Other programs' DNS questions (UDP port 53, IPv4 and IPv6) go to the DNS
 * gate when the app gives it its forwarder (--dns-gate, dnsgate.h): a program
 * that ignores the proxy then gets encrypted DNS's answer, not the network's
 * forged one. Whatever the gate does not answer goes on unchanged.
 *
 * Traffic to a local, private or special address is never changed, and a
 * reset is only dropped from a server this engine recently desynced
 * (rawscope.h). A server the decoy itself reaches and upsets (a TLS alert
 * right after a decoyed ClientHello, either way) gets no more decoys for a
 * while, only the cut (rawscope.h, "no decoy"). A server the usual way does
 * not open (its decoyed ClientHello goes out again, unanswered) gets the
 * stronger way for a while: more decoys, kept from the server by the TCP
 * timestamp, and a ClientHello for an allowed name in front of the real one
 * (rawscope.h, "escalate"; tcpdpi.h, tcpdpi_build_strong4).
 *
 * This defeats stateful DPI (Iran/China) and the inbound-RST teardown Turkish
 * networks (Türk Telekom, Turkcell) use, which the userspace engine cannot.
 *
 * Compiled only when AVEXA_RAW is defined, on Windows. Links against
 * WinDivert.dll (and needs WinDivert.sys + WinDivert64.sys present at runtime).
 * Requires Administrator (the driver loads on first open).
 *
 * The x64 Windows package ships WinDivert.dll + WinDivert64.sys next to
 * avexa-core-adv.exe (scripts/fetch-windivert.js). WinDivert has no ARM64
 * build. If the driver cannot load, the backend reports an error and the app
 * falls back to the default engine.
 *
 * A WinDivert failure is reported as a JSON line with Windows' own error
 * code (report_windivert_error): this engine always runs elevated, so the
 * code is what tells a missing file from Windows or an antivirus refusing
 * the driver (electron/security-block.js), which is what usually stops it.
 */
#ifdef AVEXA_RAW
#ifdef _WIN32

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "proto.h"
#include "udpdpi.h"
#include "platform.h"
#include "raw_windows.h"
#include "raw_desync.h"
#include "tcpdpi.h"
#include "rawscope.h"
#include "dnsgate.h"

/* ── Minimal WinDivert 2.2 declarations (avoid needing the SDK header) ───────
 * Must match include/windivert.h of the bundled release byte for byte. */
typedef struct {
  INT64  Timestamp;
  UINT32 Layer:8;
  UINT32 Event:8;
  UINT32 Sniffed:1;
  UINT32 Outbound:1;
  UINT32 Loopback:1;
  UINT32 Impostor:1;
  UINT32 IPv6:1;
  UINT32 IPChecksum:1;
  UINT32 TCPChecksum:1;
  UINT32 UDPChecksum:1;
  UINT32 Reserved1:8;
  UINT32 Reserved2;
  union {
    struct { UINT32 IfIdx; UINT32 SubIfIdx; } Network;
    UINT8 Reserved3[64];
  };
} WINDIVERT_ADDRESS; /* 80 bytes */

#define WINDIVERT_LAYER_NETWORK 0
#define WINDIVERT_HELPER_NO_REPLACE 0

typedef HANDLE (*PFN_Open)(const char*, int, INT16, UINT64);
typedef BOOL   (*PFN_Recv)(HANDLE, void*, UINT, UINT*, WINDIVERT_ADDRESS*);
typedef BOOL   (*PFN_Send)(HANDLE, const void*, UINT, UINT*, const WINDIVERT_ADDRESS*);
typedef BOOL   (*PFN_Close)(HANDLE);
typedef BOOL   (*PFN_Shutdown)(HANDLE, int);
typedef BOOL   (*PFN_CalcCsum)(void*, UINT, const WINDIVERT_ADDRESS*, UINT64);

static PFN_Open     p_Open;
static PFN_Recv     p_Recv;
static PFN_Send     p_Send;
static PFN_Close    p_Close;
static PFN_Shutdown p_Shutdown;
static PFN_CalcCsum p_CalcCsum;

static HANDLE g_handle = INVALID_HANDLE_VALUE;
static volatile int g_run = 0;
static volatile LONG g_standby = 0;   /* raw_windows_pause: hook closed, driver unloaded */
static volatile LONG g_resumes = 0;
/* unload_driver: 0 not yet, 1 under way, 2 done; set back to 0 when standby
 * ends, so the next stop unloads the driver loaded again. */
static volatile LONG g_unload_state = 0;
static int g_quic_block = 1;      /* drop QUIC Initial -> browsers fall to TCP */
static int g_udp_fake = 1;        /* decoys ahead of Discord voice datagrams */
static int g_fake_repeats = 6;    /* decoy datagrams per voice flow */
static udp_flow_table g_flows;    /* first-N-per-flow bookkeeping */
static raw_config g_cfg;
static int g_alert_watch = 0;     /* 1: inbound plaintext TLS alerts are captured */
static int g_udp_match = 0;       /* 1: the kernel tests UDP payloads (udpdpi.h) */
static uint16_t g_ipid = 0x1000; /* rolling IP id for our crafted segments */
static int g_gate = 0;            /* 1: DNS questions go to the gate (dnsgate.h) */

static uint32_t rd32be(const uint8_t *p) {
  return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];
}
static void wr32be(uint8_t *p, uint32_t v) {
  p[0]=(uint8_t)(v>>24); p[1]=(uint8_t)(v>>16); p[2]=(uint8_t)(v>>8); p[3]=(uint8_t)v;
}

/* One error line for the app (advanced-mode.js reads the status file this
 * goes to): code, Windows' error, and the plain words an older app shows. */
static void report_windivert_error(const char *code, const char *what, DWORD err) {
  fprintf(stderr, "{\"type\":\"error\",\"code\":\"%s\",\"win32\":%lu,\"msg\":\"%s failed (%lu)\"}\n",
          code, (unsigned long)err, what, (unsigned long)err);
  fflush(stderr);
}

/* Windows said "not found" (2, 3) about the driver although our files are
 * here. WinDivertOpen starts any service named "WinDivert" it finds, and
 * leaves the one it made behind when that one does not start. Two ways that
 * happens:
 *   - another program that used WinDivert (GoodbyeDPI, zapret, a VPN) left
 *     its service pointing at a folder since deleted;
 *   - the kernel cannot read the folder Avexa runs from (a network or
 *     substituted drive, a folder only this user can see).
 * repair_stale_service deletes a stopped "WinDivert" service: stopped, no
 * one uses it, and the next open makes a fresh one. One that runs is
 * someone's in use and stays. use_system_copy then puts the driver where
 * the kernel can always read it and only an administrator can write
 * (Common Files\Avexa, from the registry, never from the environment)
 * and loads it from there. Each says what it did in a "driver" line. */
static HMODULE g_wd_mod;

static int bind_windivert(HMODULE m) {
  if (!m) return -1;
  p_Open     = (PFN_Open)    GetProcAddress(m, "WinDivertOpen");
  p_Recv     = (PFN_Recv)    GetProcAddress(m, "WinDivertRecv");
  p_Send     = (PFN_Send)    GetProcAddress(m, "WinDivertSend");
  p_Close    = (PFN_Close)   GetProcAddress(m, "WinDivertClose");
  p_Shutdown = (PFN_Shutdown)GetProcAddress(m, "WinDivertShutdown");
  p_CalcCsum = (PFN_CalcCsum)GetProcAddress(m, "WinDivertHelperCalcChecksums");
  return (p_Open && p_Recv && p_Send && p_Close && p_CalcCsum) ? 0 : -1;
}

static int repair_stale_service(void) {
  int fixed = 0, gone = 0;
  SC_HANDLE scm = OpenSCManagerW(NULL, NULL, SC_MANAGER_CONNECT);
  if (!scm) return 0;
  SC_HANDLE svc = OpenServiceW(scm, L"WinDivert", SERVICE_QUERY_CONFIG | SERVICE_QUERY_STATUS | DELETE);
  if (svc) {
    SERVICE_STATUS st;
    union { QUERY_SERVICE_CONFIGW c; BYTE b[8192]; } cfg;
    DWORD need = 0;
    if (QueryServiceStatus(svc, &st) && st.dwCurrentState == SERVICE_STOPPED) {
      /* Whether its driver file is gone, for the log. */
      if (QueryServiceConfigW(svc, &cfg.c, sizeof(cfg), &need) && cfg.c.lpBinaryPathName) {
        const wchar_t *img = cfg.c.lpBinaryPathName;
        wchar_t full[1024];
        full[0] = 0;
        if (!wcsncmp(img, L"\\??\\", 4) || !wcsncmp(img, L"\\\\?\\", 4)) img += 4;
        if (!_wcsnicmp(img, L"\\SystemRoot\\", 12)) {
          UINT n = GetWindowsDirectoryW(full, 512);
          if (n > 0 && n < 512) _snwprintf(full + n, 1024 - n, L"\\%ls", img + 12); else full[0] = 0;
        } else if (img[0] && img[1] == L':') {
          _snwprintf(full, 1024, L"%ls", img);
        } else if (img[0]) {
          UINT n = GetWindowsDirectoryW(full, 512);
          if (n > 0 && n < 512) _snwprintf(full + n, 1024 - n, L"\\%ls", img); else full[0] = 0;
        }
        full[1023] = 0;
        gone = full[0] && GetFileAttributesW(full) == INVALID_FILE_ATTRIBUTES;
      }
      if (DeleteService(svc) || GetLastError() == ERROR_SERVICE_MARKED_FOR_DELETE) fixed = 1;
    }
    CloseServiceHandle(svc);
  }
  CloseServiceHandle(scm);
  printf("{\"type\":\"driver\",\"stale\":%d,\"file_gone\":%d}\n", fixed, gone);
  fflush(stdout);
  if (fixed) Sleep(300);
  return fixed;
}

/* 1 if the two files hold the same bytes. */
static int same_file(const wchar_t *a, const wchar_t *b) {
  HANDLE fa = CreateFileW(a, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, 0, NULL);
  HANDLE fb = CreateFileW(b, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, 0, NULL);
  int same = fa != INVALID_HANDLE_VALUE && fb != INVALID_HANDLE_VALUE;
  static BYTE ba[65536], bb[65536];
  while (same) {
    DWORD na = 0, nb = 0;
    if (!ReadFile(fa, ba, sizeof(ba), &na, NULL) || !ReadFile(fb, bb, sizeof(bb), &nb, NULL) || na != nb) { same = 0; break; }
    if (na == 0) break;
    if (memcmp(ba, bb, na) != 0) same = 0;
  }
  if (fa != INVALID_HANDLE_VALUE) CloseHandle(fa);
  if (fb != INVALID_HANDLE_VALUE) CloseHandle(fb);
  return same;
}

static int use_system_copy(void) {
  wchar_t dst[MAX_PATH], src[MAX_PATH], from[MAX_PATH], to[MAX_PATH];
  DWORD sz = sizeof(dst);
  int ok = 0;
  /* Common Files, as Windows keeps it (not %CommonProgramFiles%, which the
   * user who started this could have set anywhere). */
  if (RegGetValueW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion", L"CommonFilesDir",
                   RRF_RT_REG_SZ, NULL, dst, &sz) != ERROR_SUCCESS) goto out;
  dst[MAX_PATH - 1] = 0;
  size_t dl = wcslen(dst);
  if (dl < 3 || dst[1] != L':' || dl + 40 >= MAX_PATH) goto out;
  wcscat(dst, L"\\Avexa");
  if (!CreateDirectoryW(dst, NULL) && GetLastError() != ERROR_ALREADY_EXISTS) goto out;
  DWORD at = GetFileAttributesW(dst);
  if (at == INVALID_FILE_ATTRIBUTES || !(at & FILE_ATTRIBUTE_DIRECTORY) || (at & FILE_ATTRIBUTE_REPARSE_POINT)) goto out;
  DWORD n = GetModuleFileNameW(NULL, src, MAX_PATH);
  if (n == 0 || n >= MAX_PATH) goto out;
  wchar_t *slash = wcsrchr(src, L'\\');
  if (!slash) goto out;
  *slash = 0;
  if (wcslen(src) + 20 >= MAX_PATH) goto out;
  static const wchar_t *files[] = { L"WinDivert64.sys", L"WinDivert.dll" };
  for (int i = 0; i < 2; i++) {
    _snwprintf(from, MAX_PATH, L"%ls\\%ls", src, files[i]); from[MAX_PATH - 1] = 0;
    _snwprintf(to, MAX_PATH, L"%ls\\%ls", dst, files[i]); to[MAX_PATH - 1] = 0;
    /* A copy in use (the driver loaded from it) cannot be replaced: the
     * same bytes there are as good; anything else is not used. */
    CopyFileW(from, to, FALSE);
    if (!same_file(from, to)) goto out;
  }
  HMODULE m = LoadLibraryExW(to, NULL, LOAD_WITH_ALTERED_SEARCH_PATH);
  if (!m) goto out;
  if (bind_windivert(m) != 0) { bind_windivert(g_wd_mod); FreeLibrary(m); goto out; }
  g_wd_mod = m;
  ok = 1;
out:
  printf("{\"type\":\"driver\",\"copy\":%d}\n", ok);
  fflush(stdout);
  return ok;
}

static int load_windivert(void) {
  HMODULE m = LoadLibraryA("WinDivert.dll");
  /* 126: not there (quarantined?); 5, 225, 226: refused. */
  if (!m) { report_windivert_error("windivert_load", "Loading WinDivert.dll", GetLastError()); return -1; }
  g_wd_mod = m;
  if (bind_windivert(m) != 0) { fprintf(stderr, "WinDivert.dll missing exports\n"); return -1; }
  return 0;
}

/* Inject one of our crafted IPv4 segments (checksums already computed). Mirror
 * the captured outbound address but mark the checksums present so the stack
 * does not recompute (and overwrite a deliberately bad one). */
static void raw_send(const uint8_t *seg, int len, const WINDIVERT_ADDRESS *base) {
  if (len <= 0) return;
  WINDIVERT_ADDRESS a = *base;
  a.Outbound = 1;
  a.IPv6 = 0;
  a.IPChecksum = 1;
  a.TCPChecksum = 1;
  UINT sent = 0;
  p_Send(g_handle, seg, (UINT)len, &sent, &a);
}

static int decoy_ttl_for(uint32_t daddr);

/* Inject g_fake_repeats decoy UDP datagrams to the SAME 5-tuple: random
 * payload of the same length, valid checksums, and a TTL that should run out
 * before the server (the measured one when this address answered a TCP
 * handshake lately, else the fixed one). WinDivert injects via WFP and tags
 * its own packets, so these are never re-captured (no loop). */
static void send_udp_decoys(uint32_t saddr, uint32_t daddr, uint16_t sportn,
                            uint16_t dportn, int plen, const WINDIVERT_ADDRESS *addr) {
  if (plen <= 0 || plen > 1400) return;
  uint8_t buf[1600];
  WINDIVERT_ADDRESS a = *addr;
  uint32_t tick = (uint32_t)GetTickCount();
  int ttl = decoy_ttl_for(ntohl(daddr));
  for (int i = 0; i < g_fake_repeats; i++) {
    uint16_t ipid = (uint16_t)(tick + (uint32_t)i * 7u + 1u);
    uint32_t seed = saddr ^ (daddr << 1) ^ ((uint32_t)sportn << 3) ^
                    ((uint32_t)dportn << 5) ^ (uint32_t)i * 2654435761u ^ tick;
    int n = udp_build_decoy(buf, (int)sizeof(buf), saddr, daddr, sportn, dportn,
                            plen, ttl, ipid, seed);
    if (n <= 0) break;
    UINT s = 0;
    if (p_Send(g_handle, buf, (UINT)n, &s, &a)) rawscope_count(RAWSCOPE_UDP_DECOYS);
  }
}

/* The decoy's payload, written to pay (room for 1600 bytes; plen is at most
 * 1500): a name the network allows (--decoy-name), where one is given and
 * fits; else the name scrambled. Returns its length. Shared by send_fake and
 * send_strong. */
static int decoy_payload(uint8_t *pay, int cap, const uint8_t *payload, int plen,
                         const proto_info *pi, int ihl, int tcphl) {
  int dlen = proto_decoy_rename(pay, cap, payload, plen, pi->kind == PROTO_TLS,
                                 pi->host_off, pi->host_len, decoy_room(plen, ihl, tcphl));
  if (dlen > 0) {
    rawscope_count(RAWSCOPE_DECOY_NAMED);
    return dlen;
  }
  memcpy(pay, payload, (size_t)plen);
  if (pi->host_off >= 0 && pi->host_off + pi->host_len <= plen) {
    for (int i = pi->host_off; i < pi->host_off + pi->host_len; i++) pay[i] ^= 0x5a;
  } else {
    for (int i = plen / 3; i < plen; i++) pay[i] ^= 0x5a;
  }
  return plen;
}

/* Send the scrambled-SNI decoy with the effective (autottl or fixed) TTL. */
static void send_fake(const uint8_t *pkt, int len, int ihl, int tcphl, int poff,
                      const proto_info *pi, int ttl, const WINDIVERT_ADDRESS *addr) {
  int plen = len - poff;
  if (plen <= 0 || plen > 1500) return;
  uint8_t pay[1600];
  int dlen = decoy_payload(pay, (int)sizeof pay, pkt + poff, plen, pi, ihl, tcphl);
  uint8_t out[1600];
  uint32_t seq = rd32be(pkt + ihl + 4);
  int eff = ttl > 0 ? ttl : g_cfg.fake_ttl;
  int n = tcpdpi_build_segment4(out, sizeof out, pkt, ihl, pkt + ihl, tcphl,
                                g_ipid++, seq, eff, pay, dlen, 1 /* bad checksum */);
  if (n > 0) raw_send(out, n, addr);
}

/* Does an alert come from as far away as the server's own SYN-ACK did? One
 * injected by a filter on the way arrives with a different hop count, and
 * must not switch the decoy off. Unknown distance: taken as the server's. */
static int alert_from_server(uint32_t key, int ttl) {
  int known = tcpdpi_hops_get(key, now_ms());
  int h = tcpdpi_hops_from_ttl(ttl);
  if (known <= 0 || h <= 0) return 1;
  return h - known <= 1 && known - h <= 1;
}

/* Effective decoy TTL for a destination IPv4 address (network order). */
static int decoy_ttl_for(uint32_t daddr) {
  if (g_cfg.autottl) {
    int hops = tcpdpi_hops_get(daddr, now_ms());
    if (hops > 0) return tcpdpi_decoy_ttl(hops, g_cfg.autottl_margin, g_cfg.autottl_min);
  }
  return g_cfg.fake_ttl;
}

/* The stronger first segment can be sent this way: a TLS ClientHello to port
 * 443, in the default decoy mode (the fakedsplit modes are a user's own
 * choice, left as they are), and without tlsrec (whose grown connections the
 * stronger way would leave out of step with the translation table). */
static int strong_fits(const proto_info *pi, int dport) {
  return pi->kind == PROTO_TLS && dport == 443 && !g_cfg.tlsrec && g_cfg.desync_mode == RAW_DESYNC_FAKE;
}

/* The stronger first segment, only for a server the usual way did not open
 * (rawscope.h, "escalate"; tcpdpi.h, tcpdpi_build_strong4): the decoy eight
 * times ("ts" decoys where the connection carries timestamps, else the usual
 * low-TTL, bad-checksum ones), then the real segment cut after its first
 * byte, that byte behind the decoy's ClientHello as a seqovl prefix. Returns
 * 1 when it went out (the original is consumed), 0 when it could not be
 * built: then nothing was sent and the caller goes the usual way. */
static int send_strong(const uint8_t *pkt, int len, int ihl, int tcphl, int poff,
                       const proto_info *pi, const WINDIVERT_ADDRESS *addr) {
  int plen = len - poff;
  if (plen < 2 || plen > 1500) return 0;
  int otl = pkt[8] ? pkt[8] : 64;
  uint8_t pay[1600];
  int dlen = decoy_payload(pay, (int)sizeof pay, pkt + poff, plen, pi, ihl, tcphl);
  static tcpdpi_seg segs[TCPDPI_STRONG_SEGS];   /* the packet loop's alone */
  int ns = 0, ts = 0;
  if (!tcpdpi_build_strong4(segs, TCPDPI_STRONG_SEGS, &ns, &ts, pkt, ihl, pkt + ihl, tcphl,
                            g_ipid, rd32be(pkt + ihl + 4), otl, pkt + poff, plen, pay, dlen,
                            decoy_ttl_for(rd32be(pkt + 16)), TCPDPI_STRONG_REPEATS))
    return 0;
  g_ipid = (uint16_t)(g_ipid + ns);
  for (int i = 0; i < ns; i++) raw_send(segs[i].data, segs[i].len, addr);
  rawscope_count(RAWSCOPE_STRONG);
  if (ts) rawscope_count(RAWSCOPE_STRONG_TS);
  return 1;
}

/* Send the real first segment cut so that no segment carries the whole name.
 * Returns 1 when the parts went out (the original is consumed), 0 when there
 * is no name to cut or they cannot be built. */
static int send_cut(const uint8_t *pkt, int ihl, int tcphl, int poff, int plen,
                    const proto_info *pi, int disorder, const WINDIVERT_ADDRESS *addr) {
  uint32_t seq = rd32be(pkt + ihl + 4);
  int otl = pkt[8] ? pkt[8] : 64;
  int cuts[2], nc = tcpdpi_split_points(pkt + poff, plen, pi->host_off, pi->host_len, cuts);
  tcpdpi_seg segs[3]; int ns = 0;
  if (nc > 0 && tcpdpi_build_multisplit4(segs, &ns, pkt, ihl, pkt + ihl, tcphl, g_ipid, seq, otl,
                                         pkt + poff, plen, cuts, nc, disorder)) {
    g_ipid = (uint16_t)(g_ipid + ns);
    for (int i = 0; i < ns; i++) raw_send(segs[i].data, segs[i].len, addr);
    return 1;
  }
  return 0;
}

/* Handle an outbound ClientHello / first request. decoy is 0 for a server in
 * the no-decoy table: then only the cut is sent. Returns 1 if the original
 * was consumed (do not re-inject it), 0 if it must be re-injected unchanged. */
static int handle_outbound(const uint8_t *pkt, int len, int ihl, int tcphl, int poff,
                           const proto_info *pi, int decoy, const WINDIVERT_ADDRESS *addr) {
  int plen = len - poff;
  uint32_t daddr = rd32be(pkt + 16);
  uint32_t seq = rd32be(pkt + ihl + 4);
  int otl = pkt[8] ? pkt[8] : 64;
  int faked = g_cfg.desync_mode == RAW_DESYNC_FAKEDSPLIT || g_cfg.desync_mode == RAW_DESYNC_FAKEDDISORDER;

  /* tlsrec: split the ClientHello's TLS record into two records, carried in two
   * TCP segments (for a DPI that reassembles the stream, issue #48). The split
   * grows the connection by five bytes, tracked in the translation table; the
   * loop shifts its later segments. Falls through to the cut if it cannot be
   * built or tracked. */
  if (g_cfg.tlsrec && pi->kind == PROTO_TLS && pi->host_off >= 1) {
    int cuts[2], nc = tcpdpi_split_points(pkt + poff, plen, pi->host_off, pi->host_len, cuts);
    int cut = nc >= 2 ? cuts[1] : (nc == 1 ? cuts[0] : 0);
    tcpdpi_seg segs[2]; int ns = 0;
    int ok = cut > 5 && tcpdpi_build_tlsrec_pair(segs, &ns, pkt, ihl, pkt + ihl, tcphl,
                                                 g_ipid, seq, otl, pkt + poff, plen, cut);
    uint32_t saddr = rd32be(pkt + 12);
    if (ok && tcpdpi_xlate_begin(saddr, daddr, (uint16_t)((pkt[ihl] << 8) | pkt[ihl + 1]),
                                 (uint16_t)((pkt[ihl + 2] << 8) | pkt[ihl + 3]),
                                 seq + (uint32_t)plen, TCPDPI_TLSREC_GROWTH, now_ms())) {
      g_ipid = (uint16_t)(g_ipid + 2);
      if (decoy) send_fake(pkt, len, ihl, tcphl, poff, pi, decoy_ttl_for(daddr), addr);
      for (int i = 0; i < ns; i++) raw_send(segs[i].data, segs[i].len, addr);
      rawscope_count(RAWSCOPE_GROWN);
      return 1;                          /* the original is replaced by the two records */
    }
  }

  if (!decoy) {
    /* Nothing the server could take for data: just the cut, in the order the
     * chosen technique would have used. */
    if (g_cfg.split == RAW_SPLIT_OFF && !faked) return 0;
    int disorder = g_cfg.split == RAW_SPLIT_DISORDER || g_cfg.desync_mode == RAW_DESYNC_FAKEDDISORDER;
    return send_cut(pkt, ihl, tcphl, poff, plen, pi, disorder, addr);
  }

  int ttl = decoy_ttl_for(daddr);
  if (faked) {
    int split = (pi->host_off > 0 && pi->host_off < plen) ? pi->host_off : (plen > 2 ? 2 : 1);
    tcpdpi_seg segs[3]; int ns = 0;
    if (tcpdpi_build_fakedsplit4(segs, &ns, pkt, ihl, pkt + ihl, tcphl, g_ipid, seq, otl,
                                 pkt + poff, plen, split, ttl, g_cfg.fake_pattern,
                                 g_cfg.desync_mode == RAW_DESYNC_FAKEDDISORDER)) {
      g_ipid += 3;
      for (int i = 0; i < ns; i++) raw_send(segs[i].data, segs[i].len, addr);
      return 1;
    }
    return 0;
  }

  /* The proven decoy, then the real packet ... */
  send_fake(pkt, len, ihl, tcphl, poff, pi, ttl, addr);
  if (g_cfg.seqovl > 0 && plen > 0) {
    uint8_t out[1600];
    int n = tcpdpi_build_seqovl4(out, sizeof out, pkt, ihl, pkt + ihl, tcphl, g_ipid,
                                 seq, otl, pkt + poff, plen, g_cfg.seqovl, g_cfg.seqovl_pattern);
    if (n > 0) { g_ipid++; raw_send(out, n, addr); return 1; }
  }
  /* ... and the real one cut, so no segment carries the whole name: a filter
   * the decoy does not fool still never reads it. Left whole when there is no
   * name to cut or the parts cannot be built. */
  if (g_cfg.split != RAW_SPLIT_OFF)
    return send_cut(pkt, ihl, tcphl, poff, plen, pi, g_cfg.split == RAW_SPLIT_DISORDER, addr);
  return 0;
}

/* The system's DNS cache emptied (what ipconfig /flushdns does): answers the
 * network's DNS forged before the gate was there would otherwise be handed to
 * programs from it for as long as they last, with no question for the gate to
 * answer. 1 when it was. */
static int flush_dns_cache(void) {
  typedef BOOL (WINAPI *PFN_Flush)(void);
  HMODULE m = LoadLibraryA("dnsapi.dll");
  if (!m) return 0;
  PFN_Flush f = (PFN_Flush)GetProcAddress(m, "DnsFlushResolverCache");
  int ok = f && f();
  FreeLibrary(m);
  return ok;
}

/* TCP timestamps on, as Linux, macOS and Android have them by default and
 * Windows does not: the stronger way keeps its decoys from the server by the
 * timestamp ("ts", the server drops a segment whose timestamp is older than
 * the connection's), which a filter in between cannot tell from the real
 * ClientHello; without timestamps it can only send them with a low TTL,
 * which a filter farther away than that never sees (zapret's Windows
 * service turns them on for the same reason). Connections opened from now
 * on carry them. Netsh from the system folder, never one found on the PATH.
 * Returns 1 when netsh said it was done. */
static int tcp_timestamps_on(void) {
  wchar_t sys[MAX_PATH], exe[MAX_PATH + 32];
  UINT n = GetSystemDirectoryW(sys, MAX_PATH);
  if (n == 0 || n >= MAX_PATH) return 0;
  _snwprintf(exe, MAX_PATH + 32, L"%ls\\netsh.exe", sys);
  exe[MAX_PATH + 31] = 0;
  wchar_t cmd[] = L"netsh.exe interface tcp set global timestamps=enabled";
  STARTUPINFOW si; PROCESS_INFORMATION pi;
  memset(&si, 0, sizeof(si)); si.cb = sizeof(si);
  memset(&pi, 0, sizeof(pi));
  if (!CreateProcessW(exe, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) return 0;
  DWORD code = 1;
  if (WaitForSingleObject(pi.hProcess, 5000) == WAIT_OBJECT_0) GetExitCodeProcess(pi.hProcess, &code);
  else TerminateProcess(pi.hProcess, 1);
  CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
  return code == 0;
}

/* What the DNS gate sends, from its own threads (a handle takes sends from
 * any thread): an answer goes in to the program that asked, on the interface
 * its question left by; a question it does not answer goes out as it came. */
static void gate_send(const uint8_t *pkt, int len, const void *meta, int inbound) {
  if (g_handle == INVALID_HANDLE_VALUE || len <= 0 || len > 4096) return;
  WINDIVERT_ADDRESS a;
  memcpy(&a, meta, sizeof(a));
  UINT s = 0;
  if (!inbound) { p_Send(g_handle, pkt, (UINT)len, &s, &a); return; }
  uint8_t buf[4096];
  memcpy(buf, pkt, (size_t)len);
  a.Outbound = 0;
  a.Loopback = 0;
  a.Impostor = 0;
  a.IPv6 = (buf[0] >> 4) == 6;
  p_CalcCsum(buf, (UINT)len, &a, 0);
  p_Send(g_handle, buf, (UINT)len, &s, &a);
}

/* Opens the packet hook (WinDivert loads its driver for it): the filter for
 * what the loop acts on, simpler ones should the driver refuse a payload
 * test, and the repairs for a driver that would not load. 0 when open, -1
 * after saying why. At start, and again when standby ends (raw_windows_resume). */
static int open_hook(void) {
  /* The kernel filter takes only what the loop below acts on:
   *   - outbound TCP 80/443 with payload (the decoy / desync path);
   *   - outbound UDP 443 whose payload is a QUIC long header (an Initial is
   *     dropped so browsers fall back to TCP);
   *   - outbound UDP on the Discord voice / STUN ports whose payload is
   *     Discord's IP discovery request or a STUN Binding request (decoys
   *     ahead of the first datagrams of a call); the call itself stays out;
   *   - inbound TCP RST and SYN-ACK from 80/443 (the RST-drop, the hop measurement);
   *   - inbound TCP from 443 whose payload starts 15 03: a plaintext TLS alert,
   *     the sign that a decoy reached the server and broke the handshake.
   * Each clause is added only for the features that are on. Should a payload
   * test ever be refused, the filter is opened without it: the TLS alert one
   * first, then the UDP ones (the ports alone, as before). IPv6 outbound is
   * re-injected unchanged by the loop below (this backend builds IPv4 fakes). */
  char filter[2048];
  /* Why the last open failed. A filter the driver refuses (87) is followed
   * by a simpler one; any other error (the driver not loading) is kept. */
  DWORD open_err = 0;
  /* "Not found" (2, 3) with our files here: once more after a stopped
   * "WinDivert" service is deleted, then from the system's own copy
   * (repair_stale_service, use_system_copy). */
  for (int round = 0; round < 3 && g_handle == INVALID_HANDLE_VALUE; round++) {
  if (round) {
    if (open_err != ERROR_FILE_NOT_FOUND && open_err != ERROR_PATH_NOT_FOUND) break;
    if (round == 1 && !repair_stale_service()) continue;
    if (round == 2) {
      if (!use_system_copy()) break;
      /* The service the last open made from our folder, which did not start. */
      repair_stale_service();
    }
    open_err = 0;
  }
  for (int udp_how = UDP_PREFILTER_PAYLOAD; udp_how >= UDP_PREFILTER_PORTS && g_handle == INVALID_HANDLE_VALUE; udp_how--) {
    char udp[1024];
    if (udp_windivert_clause(udp, sizeof(udp), g_quic_block, g_udp_fake, udp_how) < 0) continue;
    /* With tlsrec, every outbound 443 segment is taken (pure ACKs too), so a
     * grown connection's later sequence numbers can all be shifted; 80 stays
     * payload-only. Otherwise, payload-bearing 80/443 as before. */
    int base = g_cfg.tlsrec
      ? snprintf(filter, sizeof(filter),
          "(outbound and ip and tcp and (tcp.DstPort == 443 or (tcp.DstPort == 80 and tcp.PayloadLength > 0)))")
      : snprintf(filter, sizeof(filter),
          "(outbound and ip and tcp and (tcp.DstPort == 443 or tcp.DstPort == 80) and tcp.PayloadLength > 0)");
    if (udp[0])
      base += snprintf(filter + base, sizeof(filter) - base, " or (outbound and ip and udp and %s)", udp);
    /* Other programs' DNS questions, for the gate (both address families). */
    if (g_cfg.dns_gate > 0)
      base += snprintf(filter + base, sizeof(filter) - base, " or (outbound and !loopback and udp and udp.DstPort == 53)");
    for (int watch = 1; watch >= 0; watch--) {
      char sub[256]; sub[0] = 0; int so = 0;
      /* With tlsrec, every inbound 443 segment is taken so its ack can be
       * brought back for a grown connection. */
      if (g_cfg.tlsrec) so += snprintf(sub + so, sizeof(sub) - so, "tcp.SrcPort == 443");
      if (g_cfg.drop_rst) so += snprintf(sub + so, sizeof(sub) - so, "%stcp.Rst", so ? " or " : "");
      if (g_cfg.autottl)  so += snprintf(sub + so, sizeof(sub) - so, "%s(tcp.Syn and tcp.Ack)", so ? " or " : "");
      if (watch)
        so += snprintf(sub + so, sizeof(sub) - so,
          "%s(tcp.SrcPort == 443 and tcp.PayloadLength >= 7 and tcp.Payload[0] == 21 and tcp.Payload[1] == 3)",
          so ? " or " : "");
      filter[base] = 0;
      if (sub[0])
        snprintf(filter + base, sizeof(filter) - base,
          " or (inbound and tcp and (tcp.SrcPort == 443 or tcp.SrcPort == 80) and (%s))", sub);
      g_handle = p_Open(filter, WINDIVERT_LAYER_NETWORK, 0, 0);
      if (g_handle != INVALID_HANDLE_VALUE) {
        g_alert_watch = watch;
        g_udp_match = udp[0] && udp_how == UDP_PREFILTER_PAYLOAD;
        break;
      }
      DWORD e = GetLastError();
      if (!open_err || e != ERROR_INVALID_PARAMETER) open_err = e;
    }
  }
  }
  if (g_handle == INVALID_HANDLE_VALUE) {
    /* 2: the driver file is not there; 5, 577, 1275: Windows or an
     * antivirus refused the driver (this engine is elevated already). */
    report_windivert_error("windivert_open", "WinDivertOpen", open_err ? open_err : GetLastError());
    return -1;
  }
  return 0;
}

int raw_windows_start(const raw_config *cfg) {
  g_cfg = *cfg;
  if (g_cfg.fake_ttl <= 0) g_cfg.fake_ttl = 4;
  g_quic_block = g_cfg.quic_block ? 1 : 0;
  g_udp_fake = g_cfg.udp_fake ? 1 : 0;
  g_fake_repeats = (g_cfg.fake_repeats > 0 && g_cfg.fake_repeats <= 64) ? g_cfg.fake_repeats : 6;
  g_udp_match = 0;
  udp_flow_init(&g_flows);
  tcpdpi_hops_reset();
  tcpdpi_xlate_reset();
  rawscope_touch_reset();
  rawscope_nodecoy_reset();
  rawscope_escalate_reset();
  if (load_windivert() != 0) return -1;
  if (open_hook() != 0) return -1;

  g_gate = g_cfg.dns_gate > 0 && dnsgate_start(g_cfg.dns_gate, gate_send, (int)sizeof(WINDIVERT_ADDRESS)) == 0;
  int flushed = g_gate && flush_dns_cache();
  int tcp_ts = tcp_timestamps_on();
  g_run = 1;
  printf("{\"type\":\"raw_ready\",\"backend\":\"windivert\",\"ttl\":%d,\"drop_rst\":%d,\"autottl\":%d,\"seqovl\":%d,\"split\":%d,\"mode\":%d,\"quic_block\":%d,\"udp_fake\":%d,\"alert_watch\":%d,\"udp_match\":%d,\"dns_gate\":%d,\"dns_flushed\":%d,\"tlsrec\":%d,\"decoy_names\":%d,\"tcp_ts\":%d}\n",
         g_cfg.fake_ttl, g_cfg.drop_rst, g_cfg.autottl, g_cfg.seqovl, g_cfg.split, g_cfg.desync_mode, g_quic_block, g_udp_fake, g_alert_watch, g_udp_match, g_gate, flushed, g_cfg.tlsrec, proto_decoy_name_count(), tcp_ts);
  fflush(stdout);

  uint8_t pkt[65535];
  WINDIVERT_ADDRESS addr;
  while (g_run) {
    /* Standby (raw_windows_pause): the hook closed and its driver unloaded,
     * the process kept, elevated; at its end the hook is opened again here,
     * with no permission prompt. */
    if (g_standby || g_handle == INVALID_HANDLE_VALUE) {
      if (g_standby) { Sleep(100); continue; }
      InterlockedExchange(&g_unload_state, 0);
      if (open_hook() != 0) {
        printf("{\"type\":\"raw_resume_failed\"}\n"); fflush(stdout);
        InterlockedExchange(&g_standby, 1);
        continue;
      }
      g_gate = g_cfg.dns_gate > 0 && dnsgate_start(g_cfg.dns_gate, gate_send, (int)sizeof(WINDIVERT_ADDRESS)) == 0;
      printf("{\"type\":\"raw_resumed\",\"n\":%ld,\"dns_gate\":%d}\n", (long)InterlockedIncrement(&g_resumes), g_gate);
      fflush(stdout);
      continue;
    }
    UINT len = 0;
    if (!p_Recv(g_handle, pkt, sizeof(pkt), &len, &addr)) {
      if (g_standby) continue;                     /* closed for standby */
      if (GetLastError() == ERROR_NO_DATA) break; /* shutdown */
      continue;
    }
    /* Anything we cannot safely classify is re-injected unchanged. */
    if (len < 28) { UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue; }

    /* ── Inbound: RST-drop and SYN-ACK hop measurement ───────────────────── */
    /* A reset is only dropped from a server we desynced (rawscope_touched);
     * any other host's reset passes, whatever it looks like. */
    if (!addr.Outbound) {
      if (addr.IPv6) {
        if (g_cfg.drop_rst && tcpdpi_is_injected_rst6(pkt, (int)len)) {
          if (rawscope_touched(pkt + 8, 16, now_ms())) { rawscope_count(RAWSCOPE_RST_DROPPED); continue; }
          rawscope_count(RAWSCOPE_RST_PASSED);
        }
        UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue;
      }
      int ihl = (pkt[0] & 0x0f) * 4;
      if (ihl >= 20 && (int)len >= ihl + 20) {
        const uint8_t *tcp = pkt + ihl;
        if (g_cfg.drop_rst && (tcp[13] & 0x04) && tcpdpi_is_injected_rst4(pkt, (int)len)) {
          if (rawscope_touched(pkt + 12, 4, now_ms())) {
            rawscope_count(RAWSCOPE_RST_DROPPED);
            continue;                                 /* forged RST: drop it */
          }
          rawscope_count(RAWSCOPE_RST_PASSED);
        }
        if (g_cfg.autottl && (tcp[13] & 0x02) && (tcp[13] & 0x10)) { /* SYN+ACK */
          int hops = tcpdpi_hops_from_ttl(pkt[8]);
          if (hops > 0) tcpdpi_hops_put(rd32be(pkt + 12), hops, now_ms());
        }
        /* A plaintext TLS alert from a server whose ClientHello carried a
         * decoy: noted (no decoy next time), passed on unchanged. */
        int tcphl = ((tcp[12] >> 4) & 0x0f) * 4;
        uint16_t sport = (uint16_t)((tcp[0] << 8) | tcp[1]);
        if (sport == 443 && tcphl >= 20 && ihl + tcphl < (int)len &&
            alert_from_server(rd32be(pkt + 12), pkt[8]))
          rawscope_decoy_hurt_in(pkt + 12, 4, sport, (uint16_t)((tcp[2] << 8) | tcp[3]),
                                 pkt + ihl + tcphl, (int)len - ihl - tcphl, now_ms());
        /* tlsrec: bring the acknowledgement back for a grown connection, and
         * forget it when it ends. */
        if (g_cfg.tlsrec && (tcp[13] & 0x10)) {                 /* ACK set */
          uint32_t sa = rd32be(pkt + 12), da = rd32be(pkt + 16);
          uint16_t sp = (uint16_t)((tcp[0] << 8) | tcp[1]), dp = (uint16_t)((tcp[2] << 8) | tcp[3]);
          uint32_t ack = rd32be(pkt + ihl + 8);
          int changed = tcpdpi_xlate_in(sa, da, sp, dp, &ack, now_ms());
          if (tcp[13] & 0x05) tcpdpi_xlate_end(da, sa, dp, sp);  /* FIN or RST (outbound tuple) */
          if (changed) {
            wr32be(pkt + ihl + 8, ack);
            p_CalcCsum(pkt, len, &addr, 0);
            UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue;
          }
        }
      }
      UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue; /* kept unchanged */
    }

    /* ── Outbound ───────────────────────────────────────────────────────── */
    /* A DNS question: the gate answers it, or sends it on itself. */
    if (g_gate && dnsgate_take(pkt, (int)len, &addr)) continue;
    if (addr.IPv6) { UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue; }
    int ihl = (pkt[0] & 0x0f) * 4;
    if (ihl < 20 || (int)len < ihl) { UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue; }
    int proto = pkt[9];

    if (proto == 17 /* UDP */) {
      rawscope_count(RAWSCOPE_UDP_SEEN);
      if ((int)len < ihl + 8) { UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue; }
      int poff = ihl + 8;
      int plen = (int)len - poff;
      const uint8_t *up = pkt + poff;
      uint16_t dport_h = (uint16_t)((pkt[ihl + 2] << 8) | pkt[ihl + 3]);
      int local = rawscope_local4(pkt + 16);

      /* (1) QUIC: drop the Initial so the browser falls back to TCP. Everything
       * else on 443 (Version Negotiation, short-header, non-QUIC), and any QUIC
       * to a local address, re-injects. */
      if (g_quic_block && dport_h == 443) {
        if (plen > 0 && quic_is_initial(up, plen)) {
          if (!local) {
            rawscope_count(RAWSCOPE_QUIC_DROPPED);
            /* Dropped, and answered in to the program as from the server
             * with a Version Negotiation it cannot take (udpdpi.h): it gives
             * QUIC up at once and uses TCP, not after its own timeout. */
            uint8_t vn[128];
            int vl = quic_vn_ipv4_reply(pkt, (int)len, vn, (int)sizeof(vn));
            if (vl > 0) gate_send(vn, vl, &addr, 1);
            continue;
          }
          rawscope_count(RAWSCOPE_SKIPPED);
        }
        UINT s = 0; p_Send(g_handle, pkt, len, &s, &addr);
        continue;
      }

      /* (2) Discord voice / STUN: decoys ahead of the first datagrams only,
       * never toward a local address. */
      if (g_udp_fake && discord_voice_port(dport_h) && plen > 0 && udp_is_discord_voice(up, plen)) {
        if (local) { rawscope_count(RAWSCOPE_SKIPPED); UINT s = 0; p_Send(g_handle, pkt, len, &s, &addr); continue; }
        uint32_t saddr, daddr; uint16_t sportn, dportn;
        memcpy(&saddr, pkt + 12, 4);
        memcpy(&daddr, pkt + 16, 4);
        memcpy(&sportn, pkt + ihl + 0, 2);
        memcpy(&dportn, pkt + ihl + 2, 2);
        if (udp_flow_note(&g_flows, saddr, sportn, daddr, dportn, (uint32_t)GetTickCount()))
          send_udp_decoys(saddr, daddr, sportn, dportn, plen, &addr);
      }
      /* real datagram always re-injected unchanged */
      UINT s = 0; p_Send(g_handle, pkt, len, &s, &addr);
      continue;
    }

    /* TCP: the decoy / desync. Any other protocol is re-injected unchanged. */
    if (proto != 6 || (int)len < ihl + 20) { UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue; }
    int tcphl = ((pkt[ihl + 12] >> 4) & 0x0f) * 4;
    if (tcphl < 20 || ihl + tcphl > (int)len) { UINT s; p_Send(g_handle, pkt, len, &s, &addr); continue; }
    int poff = ihl + tcphl;
    int plen = (int)len - poff;

    /* tlsrec: shift a later outbound segment's sequence for a connection whose
     * ClientHello record we grew (the ClientHello itself has no entry yet, so it
     * falls through to the desync below), and forget the connection on FIN/RST. */
    if (g_cfg.tlsrec) {
      const uint8_t *tcp = pkt + ihl;
      uint32_t sa = rd32be(pkt + 12), da = rd32be(pkt + 16);
      uint16_t sp = (uint16_t)((tcp[0] << 8) | tcp[1]), dp = (uint16_t)((tcp[2] << 8) | tcp[3]);
      uint32_t s = rd32be(pkt + ihl + 4);
      int changed = tcpdpi_xlate_out(sa, da, sp, dp, &s, now_ms());
      if (tcp[13] & 0x05) tcpdpi_xlate_end(sa, da, sp, dp);   /* FIN or RST */
      if (changed) {
        wr32be(pkt + ihl + 4, s);
        p_CalcCsum(pkt, len, &addr, 0);
        UINT sent; p_Send(g_handle, pkt, len, &sent, &addr);
        continue;
      }
    }

    int handled = 0;
    if (plen > 0) {
      uint64_t now = now_ms();
      uint16_t sport = (uint16_t)((pkt[ihl] << 8) | pkt[ihl + 1]);
      uint16_t dport = (uint16_t)((pkt[ihl + 2] << 8) | pkt[ihl + 3]);
      uint32_t seq = rd32be(pkt + ihl + 4);
      /* The client giving up on a handshake whose ClientHello carried a
       * decoy: noted, and the packet goes on unchanged below. */
      if (dport == 443) rawscope_decoy_hurt_out(pkt + 16, 4, dport, sport, seq, pkt + poff, plen, now);
      proto_info pi;
      proto_inspect(pkt + poff, (size_t)plen, &pi);
      if (pi.kind != PROTO_UNKNOWN) {
        if (rawscope_local4(pkt + 16)) {
          rawscope_count(RAWSCOPE_SKIPPED);  /* the router, the LAN, local hosts: left alone */
          UINT s = 0; p_Send(g_handle, pkt, len, &s, &addr); continue;
        }
        rawscope_touch(pkt + 16, 4, now);
        rawscope_count(RAWSCOPE_DESYNCED);
        int decoy = !rawscope_nodecoy(pkt + 16, 4, now);
        if (!decoy) rawscope_count(RAWSCOPE_NODECOY);
        else if (pi.kind == PROTO_TLS)
          rawscope_decoy_sent(pkt + 16, 4, dport, sport, rawscope_tls_next_seq(seq, pkt + poff, plen), now);
        /* A server the usual way did not open (its decoyed first segment
         * came back out unanswered): the stronger way, for it alone
         * (rawscope.h, "escalate"). Any other server, or one the decoy
         * upsets (no decoy), goes on below exactly as before. */
        rawscope_escalate_drain(now);   /* the app's cut servers, taken in here (rawscope.h) */
        if (strong_fits(&pi, dport) && rawscope_escalate_first(pkt + 16, 4, dport, sport, seq, decoy, now))
          handled = send_strong(pkt, (int)len, ihl, tcphl, poff, &pi, &addr);
        if (!handled) handled = handle_outbound(pkt, (int)len, ihl, tcphl, poff, &pi, decoy, &addr);
      }
    }
    if (!handled) { UINT s = 0; p_Send(g_handle, pkt, len, &s, &addr); } /* real packet */
  }

  return 0;
}

/* The WinDivert driver stays loaded after its last handle is closed, until a
 * restart or `sc stop WinDivert`. A game's anti-cheat that looks at the loaded
 * drivers (Riot Vanguard, among others) would still see it once Advanced mode
 * has stopped, or stepped aside for that very game, and refuse the game
 * (#56). So it is unloaded at stop, unless another program that uses the same
 * driver is running (GoodbyeDPI, zapret: --keep-driver 1, from rivals.js).
 * WinDivert marks its service for deletion when it installs it, so the stop
 * removes it as well; the next start installs it again. */
/* 0: not yet, 1: under way, 2: done. Both stop paths can get here at once
 * (the watchdog on a stop request, the packet loop as it ends): the second
 * waits for the first, since the watchdog ends the process right after. */
static void unload_driver(void) {
  if (InterlockedCompareExchange(&g_unload_state, 1, 0) != 0) {
    for (int i = 0; i < 50 && g_unload_state != 2; i++) Sleep(100);
    return;
  }
  int gone = 0;
  SC_HANDLE scm = OpenSCManagerW(NULL, NULL, SC_MANAGER_CONNECT);
  if (scm) {
    SC_HANDLE svc = OpenServiceW(scm, L"WinDivert", SERVICE_STOP | SERVICE_QUERY_STATUS);
    if (svc) {
      SERVICE_STATUS st;
      if (ControlService(svc, SERVICE_CONTROL_STOP, &st) || GetLastError() == ERROR_SERVICE_NOT_ACTIVE) {
        for (int i = 0; i < 30 && !gone; i++) {
          if (QueryServiceStatus(svc, &st) && st.dwCurrentState == SERVICE_STOPPED) gone = 1;
          else Sleep(100);
        }
      }
      CloseServiceHandle(svc);
    } else if (GetLastError() == ERROR_SERVICE_DOES_NOT_EXIST) {
      gone = 1;
    }
    CloseServiceHandle(scm);
  }
  printf("{\"type\":\"driver\",\"unloaded\":%d}\n", gone);
  fflush(stdout);
  InterlockedExchange(&g_unload_state, 2);
}

/* Standby (supervise.h, F.standby): the hook closed and the driver unloaded,
 * as at a stop, so a game's anti-cheat that looks at the loaded drivers sees
 * none, while the process, elevated, stays; raw_windows_resume opens the
 * hook again from the packet loop with no permission prompt. Until 2.6.86 a
 * game's anti-cheat or a Stop ended the process, and coming back asked for
 * the administrator's permission every time. Called from the watchdog. */
void raw_windows_pause(void) {
  if (InterlockedCompareExchange(&g_standby, 1, 0) != 0) return;
  if (g_gate) { dnsgate_stop(); g_gate = 0; }
  HANDLE h = (HANDLE)InterlockedExchangePointer((PVOID volatile *)&g_handle, INVALID_HANDLE_VALUE);
  if (h != INVALID_HANDLE_VALUE) {
    if (p_Shutdown) p_Shutdown(h, 0x1 /*WINDIVERT_SHUTDOWN_RECV*/);
    p_Close(h);
  }
  if (!g_cfg.keep_driver) unload_driver();
  printf("{\"type\":\"raw_paused\"}\n");
  fflush(stdout);
}

void raw_windows_resume(void) { InterlockedExchange(&g_standby, 0); }

/* Every stop path: the watchdog's (a stop request, Avexa gone; the process
 * ends right after) and the end of the packet loop. The handle is taken once,
 * whichever comes first. */
void raw_windows_stop(void) {
  g_run = 0;
  if (g_gate) { dnsgate_stop(); g_gate = 0; }
  HANDLE h = (HANDLE)InterlockedExchangePointer((PVOID volatile *)&g_handle, INVALID_HANDLE_VALUE);
  if (h != INVALID_HANDLE_VALUE) {
    if (p_Shutdown) p_Shutdown(h, 0x1 /*WINDIVERT_SHUTDOWN_RECV*/);
    p_Close(h);
  }
  if (!g_cfg.keep_driver) unload_driver();
}

#endif /* _WIN32 */
#endif /* AVEXA_RAW */
