#include "platform.h"
#include <string.h>
#include <stdlib.h>

#ifndef _WIN32
  #include <fcntl.h>
  #include <signal.h>
  #include <time.h>
  #include <sys/ioctl.h>
  #include <sys/resource.h>
  #ifdef __linux__
    #include <linux/sockios.h>
  #endif
#endif

int plat_init(void) {
#ifdef _WIN32
  WSADATA wsa;
  return WSAStartup(MAKEWORD(2, 2), &wsa) == 0 ? 0 : -1;
#else
  signal(SIGPIPE, SIG_IGN);
  /* Every relayed connection holds two sockets, and one that has to work
   * through its techniques holds a few more for a while. A process often
   * starts with room for only 256 (macOS) or 1024 (Linux): raise that to what
   * the system allows, as Node and the browsers do. Nothing here uses
   * select(), so a high descriptor number is no problem. */
  struct rlimit rl;
  if (getrlimit(RLIMIT_NOFILE, &rl) == 0 && rl.rlim_cur != RLIM_INFINITY && rl.rlim_cur < 8192) {
    rlim_t want = (rl.rlim_max == RLIM_INFINITY || rl.rlim_max > 8192) ? 8192 : rl.rlim_max;
    if (want > rl.rlim_cur) { rl.rlim_cur = want; setrlimit(RLIMIT_NOFILE, &rl); }
  }
  return 0;
#endif
}

void plat_cleanup(void) {
#ifdef _WIN32
  WSACleanup();
#endif
}

void sock_close(sock_t s) {
  if (s == SOCK_INVALID) return;
#ifdef _WIN32
  closesocket(s);
#else
  close(s);
#endif
}

/* Close a client's connection so that what was last sent to it arrives: a
 * socket closed with unread bytes waiting is reset at once (always on
 * Windows), and a reset can throw away a reply still on its way, such as a
 * refusal. So: no more sending, read what is left for a moment, then close. */
void sock_close_graceful(sock_t s) {
  if (s == SOCK_INVALID) return;
#ifdef _WIN32
  shutdown(s, SD_SEND);
#else
  shutdown(s, SHUT_WR);
#endif
  sock_set_timeouts(s, 100);
  char b[512];
  uint64_t end = now_ms() + 200;
  while (now_ms() < end && recv(s, b, sizeof b, 0) > 0) {}
  sock_close(s);
}

int sock_set_nodelay(sock_t s, int on) {
  int v = on ? 1 : 0;
  return setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char *)&v, sizeof(v));
}

int sock_set_keepalive(sock_t s) {
  int v = 1;
  return setsockopt(s, SOL_SOCKET, SO_KEEPALIVE, (const char *)&v, sizeof(v));
}

int sock_set_nonblock(sock_t s, int on) {
#ifdef _WIN32
  u_long m = on ? 1 : 0;
  return ioctlsocket(s, FIONBIO, &m);
#else
  int fl = fcntl(s, F_GETFL, 0);
  if (fl < 0) return -1;
  fl = on ? (fl | O_NONBLOCK) : (fl & ~O_NONBLOCK);
  return fcntl(s, F_SETFL, fl);
#endif
}

int sock_set_timeouts(sock_t s, int ms) {
#ifdef _WIN32
  DWORD t = (DWORD)ms;
  setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&t, sizeof(t));
  return setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (const char *)&t, sizeof(t));
#else
  struct timeval tv;
  tv.tv_sec = ms / 1000;
  tv.tv_usec = (ms % 1000) * 1000;
  setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
  return setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
#endif
}

int sock_get_ttl(sock_t s, int family) {
  int v = 0;
#ifdef _WIN32
  int len = sizeof(v);
#else
  socklen_t len = sizeof(v);
#endif
  int r;
  if (family == AF_INET6)
    r = getsockopt(s, IPPROTO_IPV6, IPV6_UNICAST_HOPS, (char *)&v, &len);
  else
    r = getsockopt(s, IPPROTO_IP, IP_TTL, (char *)&v, &len);
  if (r != 0 || v <= 0 || v > 255) return 64;
  return v;
}

int sock_set_ttl(sock_t s, int family, int ttl) {
  int v = ttl;
  if (family == AF_INET6)
    return setsockopt(s, IPPROTO_IPV6, IPV6_UNICAST_HOPS, (const char *)&v, sizeof(v));
  return setsockopt(s, IPPROTO_IP, IP_TTL, (const char *)&v, sizeof(v));
}

#ifdef _WIN32
/* SIO_TCP_INFO (Windows 10 1703 and later), spelled out: older SDKs and
 * MinGW headers do not have it. */
#ifndef SIO_TCP_INFO
#define SIO_TCP_INFO _WSAIORW(IOC_VENDOR, 39)
#endif
typedef struct {
  ULONG   State, Mss;
  ULONG64 ConnectionTimeMs;
  BOOLEAN TimestampsEnabled;
  ULONG   RtoUs, MinRttUs, BytesInFlight, Cwnd, SndWnd, RcvWnd, RcvBuf;
  ULONG64 BytesOut, BytesIn;
  ULONG   BytesReordered, BytesRetrans, FastRetrans, DupAcksIn, TimeoutEpisodes;
  UCHAR   SynRetrans;
} avexa_tcp_info_v0;
#endif

int sock_unacked(sock_t s) {
#if defined(_WIN32)
  DWORD ver = 0, got = 0;
  avexa_tcp_info_v0 ti;
  memset(&ti, 0, sizeof(ti));
  if (WSAIoctl(s, SIO_TCP_INFO, &ver, sizeof(ver), &ti, sizeof(ti), &got, NULL, NULL) != 0) return -1;
  if (got < offsetof(avexa_tcp_info_v0, Cwnd)) return -1;
  return ti.BytesInFlight > 0x7fffffffu ? 0x7fffffff : (int)ti.BytesInFlight;
#elif defined(__linux__)
  /* TCP_INFO first: Android lets an app's sockets answer it, where it may
   * turn the ioctl down. tcpi_unacked: segments sent and not acknowledged. */
  struct tcp_info ti;
  socklen_t len = sizeof(ti);
  memset(&ti, 0, sizeof(ti));
  if (getsockopt(s, IPPROTO_TCP, TCP_INFO, &ti, &len) == 0 && len >= offsetof(struct tcp_info, tcpi_sacked))
    return (int)ti.tcpi_unacked;
  int n = 0;
  if (ioctl(s, SIOCOUTQ, &n) == 0) return n < 0 ? 0 : n;
  return -1;
#elif defined(__APPLE__)
  int n = 0;
  socklen_t len = sizeof(n);
  if (getsockopt(s, SOL_SOCKET, SO_NWRITE, &n, &len) != 0) return -1;
  return n < 0 ? 0 : n;
#else
  (void)s;
  return -1;
#endif
}

void sock_wait_sent(sock_t s, int max_ms) {
#if defined(__linux__) && defined(SIOCOUTQNSD)
  /* Linux: wait until the not-yet-sent queue is empty so that each send()
   * leaves as its own segment (defeats autocorking/coalescing). TCP_NODELAY is
   * already set on the socket; draining SIOCOUTQNSD guarantees the bytes are on
   * the wire before the next chunk is written, so they cannot be coalesced. */
  uint64_t deadline = now_ms() + (uint64_t)max_ms;
  for (;;) {
    int pending = 0;
    if (ioctl(s, SIOCOUTQNSD, &pending) != 0) break;
    if (pending <= 0) break;
    if (now_ms() >= deadline) break;
    struct timespec ts = {0, 150000}; /* 0.15 ms */
    nanosleep(&ts, NULL);
  }
  /* A final tiny yield so the next send() starts a fresh segment even if the
   * NIC/driver briefly held the queue. */
  { struct timespec ts = {0, 300000}; nanosleep(&ts, NULL); }
#elif defined(__APPLE__)
  /* macOS has no SIOCOUTQNSD. With TCP_NODELAY set, a short sleep lets the
   * pending small segment leave before the next write, which is enough to keep
   * the SNI split across segments in practice. */
  (void)s;
  (void)max_ms;
  struct timespec ts = {0, 1500000}; /* 1.5 ms */
  nanosleep(&ts, NULL);
#else
  /* Windows: TCP_NODELAY prevents Nagle coalescing of small writes; a brief
   * sleep ensures the previous segment is handed to the stack first. */
  (void)s;
  (void)max_ms;
  sleep_ms(2);
#endif
}

int sock_connect_timeout(sock_t s, const struct sockaddr *sa, int salen, int timeout_ms) {
  if (sock_set_nonblock(s, 1) != 0) return -1;
  int r = connect(s, sa, salen);
  if (r != 0) {
    int e = sock_errno();
#ifdef _WIN32
    if (e != WSAEWOULDBLOCK && e != WSAEINPROGRESS) { sock_set_nonblock(s, 0); return -1; }
#else
    if (e != EINPROGRESS) { sock_set_nonblock(s, 0); return -1; }
#endif
#ifdef _WIN32
    WSAPOLLFD p;
    p.fd = s; p.events = POLLWRNORM; p.revents = 0;
    r = WSAPoll(&p, 1, timeout_ms);
#else
    struct pollfd p;
    p.fd = s; p.events = POLLOUT; p.revents = 0;
    do { r = poll(&p, 1, timeout_ms); } while (r < 0 && errno == EINTR);
#endif
    /* -2: nothing came back in time, which is not the same as a refusal —
     * the caller may have cut the wait short itself. */
    if (r <= 0) { sock_set_nonblock(s, 0); return r == 0 ? -2 : -1; }
    int err = 0;
#ifdef _WIN32
    int len = sizeof(err);
#else
    socklen_t len = sizeof(err);
#endif
    if (getsockopt(s, SOL_SOCKET, SO_ERROR, (char *)&err, &len) != 0 || err != 0) {
      sock_set_nonblock(s, 0);
      return -1;
    }
  }
  sock_set_nonblock(s, 0);
  return 0;
}

int sock_send_all(sock_t s, const uint8_t *buf, size_t len, int flags) {
  size_t off = 0;
  while (off < len) {
    size_t chunk = len - off;
    if (chunk > 0x40000000) chunk = 0x40000000;
#ifdef _WIN32
    int n = send(s, (const char *)buf + off, (int)chunk, flags);
#else
  #ifdef MSG_NOSIGNAL
    int n = (int)send(s, buf + off, chunk, flags | MSG_NOSIGNAL);
  #else
    int n = (int)send(s, buf + off, chunk, flags);
  #endif
#endif
    if (n < 0) {
      if (sock_errno() == SE_INTR) continue;
      return -1;
    }
    if (n == 0) return -1;
    off += (size_t)n;
  }
  return 0;
}

int sock_err_peer_gone(int err) {
#ifdef _WIN32
  return err == WSAECONNRESET || err == WSAECONNABORTED || err == WSAESHUTDOWN || err == WSAENOTCONN;
#else
  return err == ECONNRESET || err == EPIPE || err == ECONNABORTED || err == ENOTCONN;
#endif
}

int sock_wait_readable(sock_t s, int timeout_ms) {
#ifdef _WIN32
  WSAPOLLFD p;
  p.fd = s; p.events = POLLRDNORM; p.revents = 0;
  int r = WSAPoll(&p, 1, timeout_ms);
  if (r < 0) return -1;
  if (r == 0) return 0;
  return 1;
#else
  struct pollfd p;
  p.fd = s; p.events = POLLIN; p.revents = 0;
  int r;
  do { r = poll(&p, 1, timeout_ms); } while (r < 0 && errno == EINTR);
  if (r < 0) return -1;
  if (r == 0) return 0;
  return 1;
#endif
}

int sock_wait_either(sock_t a, sock_t b, int timeout_ms) {
#ifdef _WIN32
  WSAPOLLFD p[2];
  p[0].fd = a; p[0].events = POLLRDNORM; p[0].revents = 0;
  p[1].fd = b; p[1].events = POLLRDNORM; p[1].revents = 0;
  int r = WSAPoll(p, 2, timeout_ms);
#else
  struct pollfd p[2];
  p[0].fd = a; p[0].events = POLLIN; p[0].revents = 0;
  p[1].fd = b; p[1].events = POLLIN; p[1].revents = 0;
  int r;
  do { r = poll(p, 2, timeout_ms); } while (r < 0 && errno == EINTR);
#endif
  if (r < 0) return -1;
  if (r == 0) return 0;
  int mask = 0;
  if (p[0].revents) mask |= 1;
  if (p[1].revents) mask |= 2;
  return mask;
}

int sock_wait_any(const sock_t *s, int n, int timeout_ms, int *ready) {
  if (n <= 0 || n > SOCK_POLL_MAX) return -1;
#ifdef _WIN32
  WSAPOLLFD p[SOCK_POLL_MAX];
  for (int i = 0; i < n; i++) { p[i].fd = s[i]; p[i].events = POLLRDNORM; p[i].revents = 0; }
  int r = WSAPoll(p, (ULONG)n, timeout_ms);
#else
  struct pollfd p[SOCK_POLL_MAX];
  for (int i = 0; i < n; i++) { p[i].fd = s[i]; p[i].events = POLLIN; p[i].revents = 0; }
  int r;
  do { r = poll(p, (nfds_t)n, timeout_ms); } while (r < 0 && errno == EINTR);
#endif
  if (r < 0) return -1;
  int k = 0;
  for (int i = 0; i < n; i++) { ready[i] = p[i].revents != 0; k += ready[i]; }
  return k;
}

int sock_connect_start(sock_t s, const struct sockaddr *sa, int salen) {
  if (sock_set_nonblock(s, 1) != 0) return -1;
  if (connect(s, sa, salen) == 0) { sock_set_nonblock(s, 0); return 0; }
  int e = sock_errno();
#ifdef _WIN32
  if (e == WSAEWOULDBLOCK || e == WSAEINPROGRESS) return 1;
#else
  if (e == EINPROGRESS || e == EINTR) return 1;
#endif
  return -1;
}

/* Whether a connect that has come back from waiting worked. */
static int connect_ok(sock_t s) {
  int err = 0;
#ifdef _WIN32
  int len = sizeof(err);
#else
  socklen_t len = sizeof(err);
#endif
  if (getsockopt(s, SOL_SOCKET, SO_ERROR, (char *)&err, &len) != 0 || err != 0) return 0;
  sock_set_nonblock(s, 0);
  return 1;
}

int sock_connect_wait(const sock_t *s, int n, int timeout_ms, int *done) {
  if (n <= 0 || n > SOCK_POLL_MAX) return -1;
  for (int i = 0; i < n; i++) done[i] = 0;
#ifdef _WIN32
  /* select, not WSAPoll: before Windows 10 2004, WSAPoll does not report a
   * refused connect at all, so it would look like one that never answers. */
  fd_set wr, ex;
  FD_ZERO(&wr); FD_ZERO(&ex);
  for (int i = 0; i < n; i++) { FD_SET(s[i], &wr); FD_SET(s[i], &ex); }
  struct timeval tv;
  tv.tv_sec = timeout_ms / 1000; tv.tv_usec = (timeout_ms % 1000) * 1000;
  int r = select(0, NULL, &wr, &ex, &tv);
  if (r == SOCKET_ERROR) return -1;
  if (r == 0) return 0;
  int k = 0;
  for (int i = 0; i < n; i++) {
    if (FD_ISSET(s[i], &ex)) { done[i] = -1; k++; }
    else if (FD_ISSET(s[i], &wr)) { done[i] = connect_ok(s[i]) ? 1 : -1; k++; }
  }
  return k;
#else
  struct pollfd p[SOCK_POLL_MAX];
  for (int i = 0; i < n; i++) { p[i].fd = s[i]; p[i].events = POLLOUT; p[i].revents = 0; }
  int r;
  do { r = poll(p, (nfds_t)n, timeout_ms); } while (r < 0 && errno == EINTR);
  if (r < 0) return -1;
  int k = 0;
  for (int i = 0; i < n; i++) {
    if (!p[i].revents) continue;
    done[i] = (p[i].revents & POLLOUT) && connect_ok(s[i]) ? 1 : -1;
    k++;
  }
  return k;
#endif
}

/* ── threads ───────────────────────────────────────────────────────────── */

#ifdef _WIN32
typedef struct { thread_fn fn; void *arg; } win_tramp_t;
static DWORD WINAPI win_tramp(LPVOID p) {
  win_tramp_t t = *(win_tramp_t *)p;
  free(p);
  t.fn(t.arg);
  return 0;
}
#endif

int thread_spawn(thread_fn fn, void *arg, size_t stack_size) {
#ifdef _WIN32
  win_tramp_t *t = (win_tramp_t *)malloc(sizeof(*t));
  if (!t) return -1;
  t->fn = fn; t->arg = arg;
  HANDLE h = CreateThread(NULL, stack_size, win_tramp, t, STACK_SIZE_PARAM_IS_A_RESERVATION, NULL);
  if (!h) { free(t); return -1; }
  CloseHandle(h);
  return 0;
#else
  pthread_attr_t attr;
  pthread_t th;
  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  if (stack_size) pthread_attr_setstacksize(&attr, stack_size);
  int r = pthread_create(&th, &attr, fn, arg);
  pthread_attr_destroy(&attr);
  return r == 0 ? 0 : -1;
#endif
}

void mutex_init(mutex_t *m) {
#ifdef _WIN32
  InitializeCriticalSection(&m->cs);
#else
  pthread_mutex_init(&m->m, NULL);
#endif
}
void mutex_lock(mutex_t *m) {
#ifdef _WIN32
  EnterCriticalSection(&m->cs);
#else
  pthread_mutex_lock(&m->m);
#endif
}
void mutex_unlock(mutex_t *m) {
#ifdef _WIN32
  LeaveCriticalSection(&m->cs);
#else
  pthread_mutex_unlock(&m->m);
#endif
}

/* Time since boot, plus a day. Avexa starts at login, a minute after boot:
 * without the day, a time stamp set back by a time-to-live would wrap round to
 * the far future and an expired entry would look brand new. */
#define CLOCK_BASE_MS (24ull * 60 * 60 * 1000)

uint64_t now_ms(void) {
#ifdef _WIN32
  return CLOCK_BASE_MS + (uint64_t)GetTickCount64();
#else
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return CLOCK_BASE_MS + (uint64_t)ts.tv_sec * 1000ull + (uint64_t)ts.tv_nsec / 1000000ull;
#endif
}

void sleep_ms(int ms) {
#ifdef _WIN32
  Sleep((DWORD)ms);
#else
  struct timespec ts;
  ts.tv_sec = ms / 1000;
  ts.tv_nsec = (long)(ms % 1000) * 1000000L;
  nanosleep(&ts, NULL);
#endif
}

/* ── files ──────────────────────────────────────────────────────────────── */
#ifdef _WIN32
static int wide_utf8(const char *s, wchar_t *w, int cap) {
  return s && MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s, -1, w, cap) > 0;
}
FILE *fopen_utf8(const char *path, const char *mode) {
  wchar_t w[2048], m[16];
  if (!wide_utf8(path, w, 2048) || !wide_utf8(mode, m, 16)) return NULL;
  return _wfopen(w, m);
}
FILE *freopen_utf8(const char *path, const char *mode, FILE *stream) {
  wchar_t w[2048], m[16];
  if (!wide_utf8(path, w, 2048) || !wide_utf8(mode, m, 16)) return NULL;
  return _wfreopen(w, m, stream);
}
int remove_utf8(const char *path) {
  wchar_t w[2048];
  if (!wide_utf8(path, w, 2048)) return -1;
  return _wremove(w);
}
#else
FILE *fopen_utf8(const char *path, const char *mode) { return fopen(path, mode); }
FILE *freopen_utf8(const char *path, const char *mode, FILE *stream) { return freopen(path, mode, stream); }
int remove_utf8(const char *path) { return remove(path); }
#endif
