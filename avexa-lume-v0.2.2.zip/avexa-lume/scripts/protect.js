#!/usr/bin/env node
'use strict';
// Makes the copy of the app that gets packaged: electron/ and ui/ into build-src/, every
// .js obfuscated (names, strings and flow scrambled). It is a deterrent, not a lock.
// The source folders are left untouched.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const out = path.join(root, 'build-src');

let Obf;
try { Obf = require('javascript-obfuscator'); } catch { Obf = null; }
if (!Obf) { console.error('javascript-obfuscator is missing, run: npm install'); process.exit(1); }

const common = {
  compact: true, controlFlowFlattening: true, controlFlowFlatteningThreshold: 0.6,
  stringArray: true, stringArrayThreshold: 0.8, stringArrayEncoding: ['base64'], stringArrayRotate: true, stringArrayShuffle: true,
  splitStrings: true, splitStringsChunkLength: 6, identifierNamesGenerator: 'hexadecimal', renameGlobals: false,
  numbersToExpressions: true, simplify: true, transformObjectKeys: false, unicodeEscapeSequence: false,
};
const opt = (target) => ({ ...common, target });

fs.rmSync(out, { recursive: true, force: true });
function walk(src, dst, target) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) walk(s, d, target);
    else if (e.name.endsWith('.js')) fs.writeFileSync(d, Obf.obfuscate(fs.readFileSync(s, 'utf8'), opt(target)).getObfuscatedCode());
    else fs.copyFileSync(s, d);
  }
}
walk(path.join(root, 'electron'), path.join(out, 'electron'), 'node');
walk(path.join(root, 'ui'), path.join(out, 'ui'), 'browser');
console.log('protected copy written to build-src/');
