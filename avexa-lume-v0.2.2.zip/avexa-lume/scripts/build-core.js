#!/usr/bin/env node
'use strict';
// Builds the engine into core/bin/.
//   node scripts/build-core.js            native build (cc/gcc/clang, or MSVC cl on Windows)
//   node scripts/build-core.js --windows  Windows x64 .exe from any OS, needs zig (pip install ziglang)
const fs = require('fs');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');

const root = path.join(__dirname, '..');
const srcDir = path.join(root, 'core', 'src');
const sources = fs.readdirSync(srcDir).filter((f) => f.endsWith('.c')).map((f) => path.join(srcDir, f));
const outDir = path.join(root, 'core', 'bin');
fs.mkdirSync(outDir, { recursive: true });

const has = (cmd, args = ['--version']) => { const r = spawnSync(cmd, args, { stdio: 'ignore' }); return !r.error && r.status === 0; };

function zig() {
  if (has('zig', ['version'])) return ['zig'];
  const py = process.platform === 'win32' ? 'python' : 'python3';
  if (has(py, ['-m', 'ziglang', 'version'])) return [py, '-m', 'ziglang'];
  return null;
}

if (process.argv.includes('--windows')) {
  const z = zig();
  if (!z) { console.error('zig not found. Install it: pip install ziglang'); process.exit(1); }
  const out = path.join(outDir, 'avexa-core.exe');
  const libs = ['-lws2_32', '-liphlpapi'];
  execFileSync(z[0], [...z.slice(1), 'cc', '-target', 'x86_64-windows.win7-gnu', '-std=c11', '-O2', '-o', out, ...sources, ...libs], { stdio: 'inherit' });
  console.log('built', out);
  // System-wide engine (packet layer). WinDivert is loaded at run time, nothing to link.
  const adv = path.join(outDir, 'avexa-core-adv.exe');
  execFileSync(z[0], [...z.slice(1), 'cc', '-target', 'x86_64-windows.win7-gnu', '-std=c11', '-O2', '-DAVEXA_RAW', '-o', adv, ...sources, ...libs, '-ladvapi32', '-lshell32', '-luser32', '-lole32', '-loleaut32', '-luuid'], { stdio: 'inherit' });
  console.log('built', adv);
} else if (process.platform === 'win32') {
  const out = path.join(outDir, 'avexa-core.exe');
  const adv = path.join(outDir, 'avexa-core-adv.exe');
  try {
    execFileSync('cl', ['/nologo', '/O2', '/std:c11', ...sources, `/Fe:${out}`, '/link', 'ws2_32.lib', 'iphlpapi.lib'], { stdio: 'inherit' });
    execFileSync('cl', ['/nologo', '/O2', '/std:c11', '/DAVEXA_RAW', ...sources, `/Fe:${adv}`, '/link', 'ws2_32.lib', 'iphlpapi.lib', 'advapi32.lib', 'shell32.lib', 'user32.lib', 'ole32.lib', 'oleaut32.lib', 'uuid.lib'], { stdio: 'inherit' });
  } catch {
    execFileSync('clang', ['-std=c11', '-O2', '-o', out, ...sources, '-lws2_32', '-liphlpapi'], { stdio: 'inherit' });
    execFileSync('clang', ['-std=c11', '-O2', '-DAVEXA_RAW', '-o', adv, ...sources, '-lws2_32', '-liphlpapi', '-ladvapi32', '-lshell32', '-luser32', '-lole32', '-loleaut32', '-luuid'], { stdio: 'inherit' });
  }
  console.log('built', out, adv);
} else {
  const out = path.join(outDir, 'avexa-core');
  const cc = process.env.CC || (has('cc') ? 'cc' : 'gcc');
  execFileSync(cc, ['-std=c11', '-O2', '-pthread', '-D_GNU_SOURCE', '-o', out, ...sources], { stdio: 'inherit' });
  console.log('built', out);
}
