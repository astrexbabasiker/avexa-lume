#!/usr/bin/env node
'use strict';
// Downloads WinDivert (the signed packet driver the system-wide mode uses) from its
// official release and puts WinDivert.dll + WinDivert64.sys next to the engine.
//   node scripts/fetch-windivert.js [--sha256 <hash of the zip>]
// With --sha256 the download is refused unless it matches. Without it the hash is
// printed so you can compare it with the one on the release page.
const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const VERSION = '2.2.2';
const URL = `https://github.com/basil00/WinDivert/releases/download/v${VERSION}/WinDivert-${VERSION}-A.zip`;
const outDir = path.join(__dirname, '..', 'core', 'bin');
const want = (process.argv.indexOf('--sha256') > 0 ? process.argv[process.argv.indexOf('--sha256') + 1] : '').toLowerCase();

function get(url, hops = 0) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'user-agent': 'avexa-lume' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && hops < 5) { res.resume(); return resolve(get(res.headers.location, hops + 1)); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

(async () => {
  if (fs.existsSync(path.join(outDir, 'WinDivert.dll')) && fs.existsSync(path.join(outDir, 'WinDivert64.sys')) && !process.argv.includes('--force')) {
    console.log('WinDivert already in core/bin (use --force to fetch again)'); return;
  }
  const local = [path.join(outDir, `WinDivert-${VERSION}-A.zip`), path.join(__dirname, '..', `WinDivert-${VERSION}-A.zip`)].find((f) => fs.existsSync(f));
  let zip;
  if (local) { console.log('using local file', local); zip = fs.readFileSync(local); } else { console.log('downloading', URL); zip = await get(URL); }
  const sum = crypto.createHash('sha256').update(zip).digest('hex');
  console.log('sha256', sum);
  if (want && want !== sum) throw new Error('SHA-256 does not match, refusing to use the download');
  // Work inside the project folder (not Temp), so one Defender exclusion for the folder covers it.
  const tmp = path.join(__dirname, '..', '.tmp-windivert');
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp, { recursive: true });
  const zf = path.join(tmp, 'wd.zip');
  fs.writeFileSync(zf, zip);
  await new Promise((r) => setTimeout(r, 2500));   // give a virus scanner time to act
  if (!fs.existsSync(zf)) {
    console.error('\nThe downloaded zip disappeared: your antivirus removed it (WinDivert is a packet driver and is often flagged).');
    console.error('Fix: in Windows Security > Protection history, allow it, or exclude this project folder, then run build.bat again.');
    console.error('Or download WinDivert-' + VERSION + '-A.zip yourself from the official page and put it in core\\bin.');
    process.exit(1);
  }
  if (process.platform === 'win32') {
    execFileSync('powershell', ['-NoProfile', '-Command', `Expand-Archive -LiteralPath '${zf}' -DestinationPath '${tmp}' -Force`], { stdio: 'inherit' });
  } else {
    execFileSync('unzip', ['-o', '-q', zf, '-d', tmp], { stdio: 'inherit' });
  }
  const root = path.join(tmp, `WinDivert-${VERSION}-A`);
  fs.mkdirSync(outDir, { recursive: true });
  for (const f of ['WinDivert.dll', 'WinDivert64.sys']) fs.copyFileSync(path.join(root, 'x64', f), path.join(outDir, f));
  try { fs.copyFileSync(path.join(root, 'LICENSE'), path.join(outDir, 'WinDivert-LICENSE.txt')); } catch { /* optional */ }
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log('WinDivert', VERSION, 'copied to', outDir);
})().catch((e) => { console.error('fetch failed:', e.message); process.exit(1); });
