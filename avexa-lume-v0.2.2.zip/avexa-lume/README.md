# Avexa Lume

Free, open-source DPI bypass for Windows. Lume reshapes the first packet of each
connection (TLS SNI / HTTP Host) so the ISP's inspection cannot read which site you
open, and answers DNS over encrypted DNS. Not a VPN, no servers.

## Modes

- **System-wide (default):** packet layer (WinDivert). Covers every program on the PC
  (Roblox, Discord, browsers, games), nothing to set per app. Needs administrator.
- **Compatibility (proxy):** local SOCKS5 + system PAC, no administrator, but only for
  programs that follow the system proxy. Used automatically if system-wide cannot start.

## Build the EXE (Windows)

Double-click `build.bat` (needs Node.js and Python). It builds both engines, fetches
WinDivert, scrambles the code and produces `AvexaLume.exe` (single file) and `dist/AvexaLume-Setup.exe`.

Dev: `npm install`, `npm run build:core:win`, `npm run fetch:windivert`, then `npm start`
(no administrator needed; Windows asks once for a permission).

Tests: `npm test`. Notes for the next developer: `HANDOFF.md`.

## License

Proprietary, see `LICENSE`. Third-party notices: `THIRD-PARTY-LICENSES.txt` (must ship with the app).
