'use strict';
const $ = (id) => document.getElementById(id);
const BOOLS = ['doh', 'autostart', 'startProtected', 'closeToTray', 'strong'];
const root = document.documentElement;
const TARGETS = [
  ['roblox', 'Roblox', 'www.roblox.com'], ['robloxApi', 'Roblox API', 'apis.roblox.com'], ['robloxCdn', 'Roblox CDN', 'setup.rbxcdn.com'],
  ['discord', 'Discord', 'discord.com'], ['discordCdn', 'Discord CDN', 'cdn.discordapp.com'], ['discordGw', 'Discord Gateway', 'gateway.discord.gg'],
];

let lang = 'tr';
const t = (k, a) => {
  const s = (window.I18N[lang] && window.I18N[lang][k]) || window.I18N.en[k] || k;
  return a ? s.replace(/\{(\w+)\}/g, (_, n) => (a[n] != null ? a[n] : '')) : s;
};
function applyI18n() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach((e) => { e.textContent = t(e.dataset.i18n); });
  document.querySelectorAll('[data-i18n-title]').forEach((e) => { e.title = t(e.dataset.i18nTitle); });
  document.querySelectorAll('[data-i18n-aria]').forEach((e) => { e.setAttribute('aria-label', t(e.dataset.i18nAria)); });
}

function bytes(n) {
  if (n < 1024) return Math.round(n) + ' B';
  const u = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return n.toFixed(n < 10 ? 1 : 0) + ' ' + u[i];
}
function clock(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0');
}

/* Navigation */
document.querySelectorAll('.nav').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.nav').forEach((x) => x.classList.toggle('active', x === b));
  document.querySelectorAll('.page').forEach((p) => p.classList.toggle('active', p.id === 'page-' + b.dataset.page));
}));

/* Activity chart: one point a second */
const SAMPLES = 60;
const history = new Array(SAMPLES).fill(0);
let lastSample = 0;
let unit = 'bytes';
function drawSpark() {
  const c = $('spark');
  const dpr = window.devicePixelRatio || 1;
  const w = c.clientWidth, h = c.clientHeight;
  if (!w || !h) return;
  if (c.width !== Math.round(w * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); }
  const g = c.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);
  const rgb = getComputedStyle(root).getPropertyValue('--rgb').trim() || '255,181,71';
  const max = Math.max(...history, unit === 'bytes' ? 1024 : 4);
  const pts = history.map((v, i) => [(i / (SAMPLES - 1)) * w, h - 4 - (v / max) * (h - 12)]);
  g.beginPath();
  pts.forEach(([x, y], i) => { if (!i) g.moveTo(x, y); else { const [px, py] = pts[i - 1]; const mx = (px + x) / 2; g.bezierCurveTo(mx, py, mx, y, x, y); } });
  g.lineWidth = 2; g.lineJoin = 'round'; g.strokeStyle = `rgb(${rgb})`; g.stroke();
  g.lineTo(w, h); g.lineTo(0, h); g.closePath();
  const grad = g.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, `rgba(${rgb},.30)`); grad.addColorStop(1, `rgba(${rgb},0)`);
  g.fillStyle = grad; g.fill();
}

/* Settings controls */
function markSeg(id, value) {
  document.querySelectorAll(`#${id} button`).forEach((b) => b.classList.toggle('on', b.dataset.v === value));
}
for (const id of ['theme', 'accent', 'mode', 'lang']) {
  $(id).addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (id === 'theme' || id === 'accent') { root.dataset[id] = b.dataset.v; drawSpark(); }
    markSeg(id, b.dataset.v);
    window.lume.set(id, b.dataset.v);
  });
}
for (const k of BOOLS) $(k).addEventListener('change', (e) => window.lume.set(k, e.target.checked));
$('power').addEventListener('click', () => window.lume.toggle());
$('restartDiscord').addEventListener('click', () => window.lume.restartDiscord());
$('openLog').addEventListener('click', () => window.lume.openLog());
$('adminBtn').addEventListener('click', () => window.lume.admin());
$('bannerBtn').addEventListener('click', () => window.lume.admin());
$('runDiag').addEventListener('click', () => window.lume.diag());

let toastTimer = null;
function toast(text) {
  const el = $('toast');
  el.textContent = text; el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

function renderDiag(d) {
  const list = $('tests');
  list.textContent = '';
  const byId = new Map((d.results || []).map((r) => [r.id, r]));
  $('diagHint').hidden = d.running || byId.size > 0;
  $('runDiag').disabled = !!d.running;
  $('runDiag').textContent = d.running ? t('diagRunning') : t('diagRun');
  if (!d.running && !byId.size) return;
  for (const [id, name, host] of TARGETS) {
    const r = byId.get(id);
    const li = document.createElement('li');
    li.className = !r ? 'wait' : r.ok ? 'ok' : 'bad';
    const dot = document.createElement('i');
    const nm = document.createElement('b'); nm.textContent = name;
    const hs = document.createElement('small'); hs.textContent = host;
    const st = document.createElement('span');
    st.textContent = !r ? '…' : r.ok ? t('diagOk') + ' · ' + r.ms + ' ms'
      : t('diagFail') + ' · ' + t(r.stage === 'dns' ? 'stageDns' : r.stage === 'tls' ? 'stageTls' : 'stageHttp');
    li.append(dot, nm, hs, st);
    list.appendChild(li);
  }
}
let wasRunning = false;
function diagToast(d) {
  if (wasRunning && !d.running && d.results.length) {
    toast(d.results.every((r) => r.ok) ? t('diagAllOk') : t('diagSome'));
  }
  wasRunning = !!d.running;
}

function render(s) {
  lang = s.settings.lang === 'auto' ? (String(s.locale || '').toLowerCase().startsWith('tr') ? 'tr' : 'en') : s.settings.lang;
  applyI18n();
  const sys = s.active === 'system';
  document.body.classList.toggle('on', s.on);
  document.body.classList.toggle('busy', s.busy);
  document.body.classList.toggle('sys', sys);
  root.dataset.theme = s.settings.theme;
  root.dataset.accent = s.settings.accent;
  for (const k of ['theme', 'accent', 'mode', 'lang']) markSeg(k, s.settings[k]);

  $('sideState').textContent = s.busy ? t('working') : s.on ? t('on') : t('off');
  $('title').textContent = s.busy ? t('titleBusy') : s.on ? t('titleOn') : t('titleOff');
  $('note').textContent = s.platform !== 'win32' ? t('onlyWin')
    : s.note ? t(s.note.k, s.note.a)
    : s.on ? t(sys ? 'noteOnSystem' : 'noteOnProxy') : t('noteOff');
  $('ver').textContent = 'v' + s.version;
  $('aboutVer').textContent = t('version') + s.version;

  const pill = $('modePill');
  pill.hidden = !s.on;
  pill.classList.toggle('sys', sys);
  $('modeText').textContent = t(sys ? 'modeSystem' : 'modeProxy');

  // Tiles depend on the mode that is really running.
  if (sys) {
    $('s1').textContent = (s.sys.desynced || 0).toLocaleString(); $('l1').textContent = t('s_unblocked');
    $('s2').textContent = ((s.doh && s.doh.answered || 0) + (s.sys.dns || 0)).toLocaleString(); $('l2').textContent = t('s_dns');
    $('s3').textContent = s.sys.since ? clock(Date.now() - s.sys.since) : '0:00'; $('l3').textContent = t('s_time');
    $('actTitle').textContent = t('actSystem');
  } else {
    $('s1').textContent = (s.stats.conns_total || 0).toLocaleString(); $('l1').textContent = t('s_conns');
    $('s2').textContent = (s.stats.desync || 0).toLocaleString(); $('l2').textContent = t('s_unblocked');
    $('s3').textContent = bytes((s.stats.bytes_up || 0) + (s.stats.bytes_down || 0)); $('l3').textContent = t('s_data');
    $('actTitle').textContent = t('actProxy');
  }
  const nextUnit = sys ? 'count' : 'bytes';
  if (nextUnit !== unit) { history.fill(0); unit = nextUnit; }
  const now = performance.now();
  if (now - lastSample > 800) { history.push(s.on ? s.rate || 0 : 0); history.shift(); lastSample = now; }
  const cur = history[history.length - 1];
  $('speed').textContent = unit === 'bytes' ? bytes(cur) + '/s' : cur.toFixed(cur < 10 ? 1 : 0) + '/s';
  drawSpark();

  // Warnings: system mode was wanted and could not start.
  const fb = s.fellBack;
  $('banner').hidden = !fb;
  if (fb) {
    $('bannerTitle').textContent = t('fbTitle');
    $('bannerBody').textContent = t(fb.k, fb.a) + (fb.a && fb.a.code ? ' (' + fb.a.code + ')' : '');
    $('bannerBtn').hidden = fb.k !== 'needAdmin';
    $('bannerBtn').textContent = t('fbAdminBtn');
  }
  $('adminRow').hidden = s.perm || s.platform !== 'win32';
  $('adminBtn').hidden = $('adminRow').hidden;

  renderDiag(s.diag || { running: false, results: [] });
  diagToast(s.diag || { running: false, results: [] });

  const d = s.discord || {};
  $('restartDiscord').hidden = !d.installed;
  const dInstalled = d.installed;
  $('dState').textContent = !dInstalled ? t('dNone')
    : !s.on ? t('dWait')
    : sys ? t('dSystem')
    : d.okAt ? t('dChecked') + new Date(d.okAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
    : d.requests ? t('dCovered') + ' · ' + d.requests + t('dProxyReq') : t('dCovered');

  // "Recently opened" is only filled by the proxy engine.
  $('recentCard').hidden = sys;
  const list = $('sites');
  list.textContent = '';
  for (const site of s.sites || []) {
    const li = document.createElement('li');
    li.textContent = site.host;
    if (!site.ok) li.className = 'bad';
    list.appendChild(li);
  }
  $('empty').hidden = !!(s.sites && s.sites.length);

  for (const k of BOOLS) $(k).checked = !!s.settings[k];
  document.body.classList.add('ready');
}

window.addEventListener('resize', drawSpark);
window.lume.onState(render);
