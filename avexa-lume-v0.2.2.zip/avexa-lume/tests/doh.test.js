'use strict';
// Run: node tests/doh.test.js
const dgram = require('dgram');
const assert = require('assert');
const { DohForwarder } = require('../electron/doh');

(async () => {
  const calls = [];
  // Route 1.1.1.1 is "blocked"; 8.8.8.8 answers. The forwarder must fail over.
  const f = new DohForwarder({
    routes: [{ ip: '1.1.1.1', path: '/q' }, { ip: '8.8.8.8', path: '/q' }],
    post: async (route, body) => {
      calls.push(route.ip);
      if (route.ip === '1.1.1.1') throw new Error('timeout');
      const a = Buffer.from(body); a[2] |= 0x80; return a;     // echo with QR set
    },
  });
  const port = await f.start();
  const q = Buffer.alloc(32, 7); q[0] = 0xab; q[1] = 0xcd;
  const c = dgram.createSocket('udp4');
  const ans = await new Promise((res, rej) => {
    c.once('message', res);
    c.send(q, port, '127.0.0.1');
    setTimeout(() => rej(new Error('no answer')), 2000);
  });
  assert.strictEqual(ans[0], 0xab); assert.strictEqual(ans[1], 0xcd);
  assert.ok(ans[2] & 0x80);
  assert.deepStrictEqual(calls, ['1.1.1.1', '8.8.8.8']);

  // Second question: the failed route is rested, so it goes straight to 8.8.8.8.
  calls.length = 0;
  const ans2 = await new Promise((res) => { c.once('message', res); c.send(q, port, '127.0.0.1'); });
  assert.ok(ans2.length === 32);
  assert.strictEqual(calls[0], '8.8.8.8');

  // Garbage (too short) is ignored, never answered.
  let got = false; c.once('message', () => { got = true; });
  c.send(Buffer.from([1, 2, 3]), port, '127.0.0.1');
  await new Promise((r) => setTimeout(r, 300));
  assert.strictEqual(got, false);

  c.close(); f.stop();
  console.log('doh forwarder: ok (failover, rest, ignore junk)');
})().catch((e) => { console.error(e); process.exit(1); });
