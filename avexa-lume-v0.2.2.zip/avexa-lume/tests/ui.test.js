'use strict';
// Every key the window and the main process use exists in both languages.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const ui = path.join(__dirname, '..', 'ui');
const ctx = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(ui, 'i18n.js'), 'utf8'), ctx);
const { tr, en } = ctx.window.I18N;

const html = fs.readFileSync(path.join(ui, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(ui, 'app.js'), 'utf8') + fs.readFileSync(path.join(__dirname, '..', 'electron', 'main.js'), 'utf8')
  + fs.readFileSync(path.join(__dirname, '..', 'electron', 'advanced.js'), 'utf8');
const keys = new Set();
for (const m of html.matchAll(/data-i18n(?:-title|-aria)?="(\w+)"/g)) keys.add(m[1]);
for (const m of js.matchAll(/\bt\('(\w+)'/g)) keys.add(m[1]);
for (const m of js.matchAll(/\bsay\('(\w+)'/g)) keys.add(m[1]);
for (const m of js.matchAll(/\bt\(sys \? '(\w+)' : '(\w+)'/g)) { keys.add(m[1]); keys.add(m[2]); }
for (const m of js.matchAll(/'(missingDll|avBlocked|needAdmin|missingSys|driverSignature|engineFail)'/g)) keys.add(m[1]);
for (const k of ['noteOnSystem', 'noteOnProxy', 'modeSystem', 'modeProxy', 'stageDns', 'stageTls', 'stageHttp', 'diagOk', 'diagFail',
  'engineMissing', 'notWindows', 'missingFiles', 'sysOn', 'proxyOn']) keys.add(k);

const missing = [];
for (const k of keys) { if (!(k in tr)) missing.push('tr:' + k); if (!(k in en)) missing.push('en:' + k); }
assert.deepStrictEqual(missing, [], 'missing translations: ' + missing.join(', '));
// ids the script reads must exist in the page
for (const m of fs.readFileSync(path.join(ui, 'app.js'), 'utf8').matchAll(/\$\('(\w+)'\)/g)) {
  assert.ok(html.includes(`id="${m[1]}"`), 'index.html has no #' + m[1]);
}
console.log('ui: ok (' + keys.size + ' keys in both languages, all element ids present)');
