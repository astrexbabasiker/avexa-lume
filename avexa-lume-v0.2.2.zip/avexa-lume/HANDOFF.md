# Avexa Lume — devir notu (başka bir yapay zekaya / geliştiriciye ver)

## Amaç
Windows için ücretsiz DPI aşıcı (Discord, Roblox, engelli siteler). Hedef: **uygulama seçmeden, bilgisayardaki tüm uygulamalar için çalışsın**, tek EXE olsun.

## Sorun neydi
v0.1 sadece SOCKS5 proxy + sistem PAC kullanıyordu. Roblox oyunu / Discord gibi uygulamalar sistem proxy'sini dinlemiyor, bu yüzden Roblox açılmadı.

## v0.2'de yapılanlar
- **Sistem geneli mod** (varsayılan): `core/` içindeki paket katmanı motoru (`avexa-core-adv.exe`, WinDivert) uygulamaya bağlandı. Proxy ayarı gerekmez, her uygulamanın trafiği işlenir.
  - `electron/advanced.js`: motoru başlatır, `raw_ready`/`error` olaylarını okur, Windows hata kodlarını anlaşılır mesaja çevirir.
  - `electron/doh.js`: yerel UDP→DoH yönlendirici. Motorun `--dns-gate` özelliği diğer uygulamaların DNS'ini buna verir (sahte DNS cevabı engellenir). Test: `tests/doh.test.js`.
  - `electron/main.js`: mod mantığı. Sistem modu açılamazsa (yönetici yok, sürücü engellendi, dosya yok) **otomatik uyumluluk (proxy) moduna düşer** ve nedenini arayüzde gösterir.
  - Yönetici gerekmez: ilk kullanımda Windows bir kez izin sorar (`--task-install-only`), motor zamanlanmış görev olarak kurulur; sonra uygulama `request` dosyası yazıp görevi başlatır (çekirdekteki advtask.c). Uygulamanın kendisi normal kullanıcıyla çalışır.
- **Bağlantı testi** (`electron/diag.js`): Roblox/Discord adreslerine gerçek TLS+HTTPS isteği atar, sonucu arayüzde gösterir.
- **Arayüz**: TR/EN dil (otomatik), mod seçici, "Güçlü mod" (tlsrec), uyarı bandı, bağlantı testi kartı, canlı etkinlik grafiği, ikon. Test: `tests/ui.test.js`.
- **Derleme**: `build.bat` (tek tık), `scripts/build-core.js --windows` artık normal + adv exe üretir, `scripts/fetch-windivert.js` sürücüyü resmi release'ten indirir. `npm run dist:win` hem kurulumlu (nsis) hem taşınabilir (portable) EXE üretir.

## Test edilmedi / bilinmeyenler (dürüst liste)
1. `avexa-core-adv.exe` Linux'ta derlenemedi (Windows API). `-DAVEXA_RAW` ile zig/cl/clang derlemesinde **link hatası** çıkabilir; çıkarsa eksik `-l...` kütüphanesini `scripts/build-core.js` listesine ekle.
2. Gerçek Windows'ta, gerçek Roblox/Discord ile çalıştırılmadı. İlk iş: `build.bat`, sonra yönetici olarak aç, "Şimdi test et".
3. `fetch-windivert.js` indirmenin SHA-256'sını yazdırır ama sabit bir hash'e karşı doğrulamaz (offline hash doğrulayamadım). `--sha256 <hash>` ile doğrulat.
4. Roblox sunucuları IP düzeyinde engelliyse hiçbir DPI aşıcı çözmez (VPN gerekir).
5. Antivirüs WinDivert sürücüsünü engelleyebilir; uygulama bunu hata koduyla söyler.
6. Roblox'un anti-cheat'i (Hyperion) ile çakışma görülürse motorda `standby` (supervise.c) özelliği var, bağlanmadı.

## Sıradaki işler (öncelik sırasıyla)
1. Windows'ta derle, hataları düzelt, Roblox'ta dene (`lume.log` + test kartı).
2. Tek seferlik yönetici izni: `core/src/advtask.c` zaten hazır (`--task-install-only`); `advanced.js` buna bağlanırsa her açılışta UAC çıkmaz.
3. Motor durdurmayı temiz yap: `--status-file` + `.stop` dosyası (şu an süreç sonlandırılıyor, OS sürücü tutamacını kapatıyor).
4. Uygulama başına dışlama listesi (isteğe bağlı) ve otomatik güncelleme.
5. İmzalı (code-signing) EXE; SmartScreen uyarısını azaltır.

## Gerekli beceriler
Electron/Node (IPC, tray, electron-builder), Windows ağ bilgisi (WinDivert, UAC, schtasks), C (core/ derleme sorunları), HTML/CSS arayüz.

## v0.2.1
- Marka: çekirdekteki eski proje adı her yerden kaldırıldı (dosya, görev, yol, arayüz). MIT şartı gereği telif satırı `THIRD-PARTY-LICENSES.txt` içinde kalmak zorunda, silme.
- Linker hatası: `oleaut32`/`uuid` eklendi.
- `scripts/protect.js` kodu karıştırır (obfuscation); çözülmez değil, caydırıcı. Henüz sığmayanlar: Electron fuse/asar bütünlük doğrulaması, ek temalar, kendi arka plan görseli.
