'use strict';
// Local encrypted-DNS forwarder for system-wide mode.
//
// The packet engine (--dns-gate) hands every program's plain DNS question to
// 127.0.0.1:<port> over UDP. We repeat it to a public DoH resolver by IP
// address (so no server name travels in the clear either) and return the
// answer unchanged. Several routes, health-ranked, so one blocked resolver
// does not stop DNS.
const dgram = require('dgram');
const https = require('https');
const { EventEmitter } = require('events');

const ROUTES = [
  { ip: '1.1.1.1', path: '/dns-query' },
  { ip: '1.0.0.1', path: '/dns-query' },
  { ip: '8.8.8.8', path: '/dns-query' },
  { ip: '8.8.4.4', path: '/dns-query' },
  { ip: '9.9.9.9', path: '/dns-query' },
  { ip: '149.112.112.112', path: '/dns-query' },
];
const PORTS = [10853, 18853, 28853, 0];
const TIMEOUT_MS = 2200;
const REST_MS = 20000;

class DohForwarder extends EventEmitter {
  // `post(route, buf)` can be replaced in tests.
  constructor({ post, routes } = {}) {
    super();
    this.routes = (routes || ROUTES).map((r) => ({ ...r, badUntil: 0, ok: 0, fail: 0 }));
    this.post = post || this._post.bind(this);
    this.sock = null;
    this.port = 0;
    this.answered = 0;
    this.failed = 0;
    this.agents = new Map();
  }

  _agent(ip) {
    if (!this.agents.has(ip)) this.agents.set(ip, new https.Agent({ keepAlive: true, maxSockets: 4, timeout: 8000 }));
    return this.agents.get(ip);
  }

  _post(route, body) {
    return new Promise((resolve, reject) => {
      const req = https.request({
        host: route.ip, port: 443, path: route.path, method: 'POST', agent: this._agent(route.ip),
        headers: { 'content-type': 'application/dns-message', accept: 'application/dns-message', 'content-length': body.length },
        timeout: TIMEOUT_MS, minVersion: 'TLSv1.2',
      }, (res) => {
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
        const chunks = []; let size = 0;
        res.on('data', (c) => { size += c.length; if (size > 65535) { req.destroy(); reject(new Error('too big')); } else chunks.push(c); });
        res.on('end', () => resolve(Buffer.concat(chunks)));
        res.on('error', reject);
      });
      req.on('timeout', () => req.destroy(new Error('timeout')));
      req.on('error', reject);
      req.end(body);
    });
  }

  // Healthy routes first, the ones that just failed last.
  _order() {
    const now = Date.now();
    return [...this.routes].sort((a, b) => (a.badUntil > now) - (b.badUntil > now));
  }

  async resolve(query) {
    for (const r of this._order().slice(0, 4)) {
      try {
        const ans = await this.post(r, query);
        if (ans && ans.length >= 12) { r.ok++; r.badUntil = 0; return ans; }
        throw new Error('short answer');
      } catch (e) {
        r.fail++; r.badUntil = Date.now() + REST_MS;
        this.emit('log', 'doh ' + r.ip + ': ' + e.message);
      }
    }
    return null;
  }

  _bind(port) {
    return new Promise((resolve, reject) => {
      const s = dgram.createSocket('udp4');
      s.once('error', reject);
      s.bind(port, '127.0.0.1', () => { s.removeListener('error', reject); resolve(s); });
    });
  }

  async start() {
    if (this.sock) return this.port;
    for (const p of PORTS) {
      try { this.sock = await this._bind(p); break; } catch { /* next port */ }
    }
    if (!this.sock) throw new Error('No free UDP port for the DNS forwarder');
    this.port = this.sock.address().port;
    this.sock.on('error', (e) => this.emit('log', 'doh socket: ' + e.message));
    this.sock.on('message', (msg, rinfo) => {
      if (msg.length < 12 || msg.length > 4096) return;
      this.resolve(Buffer.from(msg)).then((ans) => {
        if (!this.sock) return;
        if (ans) { this.answered++; this.sock.send(ans, rinfo.port, rinfo.address); } else this.failed++;
      });
    });
    return this.port;
  }

  stop() {
    if (this.sock) { try { this.sock.close(); } catch { /* closed */ } this.sock = null; }
    for (const a of this.agents.values()) { try { a.destroy(); } catch { /* gone */ } }
    this.agents.clear();
    this.port = 0;
  }
}

module.exports = { DohForwarder, ROUTES };
