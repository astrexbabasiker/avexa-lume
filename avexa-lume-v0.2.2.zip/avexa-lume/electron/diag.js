'use strict';
// "Does it really open?" Tries a real TLS handshake and HTTPS request to each
// target the way any program would (system DNS, no proxy), so in system-wide
// mode it shows exactly what Roblox or Discord would get.
const dns = require('dns');
const tls = require('tls');
const https = require('https');

const TARGETS = [
  { id: 'roblox', name: 'Roblox', host: 'www.roblox.com', path: '/' },
  { id: 'robloxApi', name: 'Roblox API', host: 'apis.roblox.com', path: '/' },
  { id: 'robloxCdn', name: 'Roblox CDN', host: 'setup.rbxcdn.com', path: '/version' },
  { id: 'discord', name: 'Discord', host: 'discord.com', path: '/api/v9/gateway' },
  { id: 'discordCdn', name: 'Discord CDN', host: 'cdn.discordapp.com', path: '/' },
  { id: 'discordGw', name: 'Discord Gateway', host: 'gateway.discord.gg', path: '/' },
];

function one(t, timeout = 7000) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const res = { id: t.id, name: t.name, host: t.host, ok: false, ms: 0, stage: 'dns', error: '' };
    const finish = (extra) => { Object.assign(res, extra, { ms: Date.now() - t0 }); resolve(res); };
    dns.lookup(t.host, { family: 4 }, (err, addr) => {
      if (err) return finish({ error: err.code || err.message });
      res.stage = 'tls'; res.addr = addr;
      const sock = tls.connect({ host: addr, port: 443, servername: t.host, timeout }, () => {
        sock.destroy();
        res.stage = 'http';
        const req = https.request({ host: t.host, port: 443, path: t.path, method: 'GET', timeout, headers: { 'user-agent': 'Mozilla/5.0 AvexaLume', accept: '*/*' } }, (r) => {
          r.resume();
          // Any HTTP status means the site answered; a block page would not get this far.
          finish({ ok: true, stage: 'done', status: r.statusCode });
        });
        req.on('timeout', () => req.destroy(new Error('timeout')));
        req.on('error', (e) => finish({ error: e.code || e.message }));
        req.end();
      });
      sock.on('timeout', () => sock.destroy(new Error('timeout')));
      sock.on('error', (e) => finish({ error: e.code || e.message }));
    });
  });
}

async function runAll(onEach) {
  const out = await Promise.all(TARGETS.map(async (t) => { const r = await one(t); if (onEach) onEach(r); return r; }));
  return out;
}

module.exports = { runAll, one, TARGETS };
