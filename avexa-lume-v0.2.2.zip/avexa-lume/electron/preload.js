'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lume', {
  toggle: () => ipcRenderer.invoke('lume:toggle'),
  set: (key, value) => ipcRenderer.invoke('lume:set', key, value),
  restartDiscord: () => ipcRenderer.invoke('lume:restart-discord'),
  openLog: () => ipcRenderer.invoke('lume:open-log'),
  admin: () => ipcRenderer.invoke('lume:admin'),
  diag: () => ipcRenderer.invoke('lume:diag'),
  onState: (cb) => ipcRenderer.on('lume:state', (_e, s) => cb(s)),
});
