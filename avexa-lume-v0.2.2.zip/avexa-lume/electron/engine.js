'use strict';
// Starts the bundled engine (core/) and turns its JSON lines into events.
const { spawn } = require('child_process');
const { EventEmitter } = require('events');
const path = require('path');
const fs = require('fs');

function enginePath(isPackaged) {
  const exe = process.platform === 'win32' ? 'avexa-core.exe' : 'avexa-core';
  const candidates = isPackaged
    ? [path.join(process.resourcesPath, 'core', exe)]
    : [path.join(__dirname, '..', 'core', 'bin', exe), path.join(__dirname, '..', 'core', exe)];
  return candidates.find((p) => fs.existsSync(p)) || null;
}

class Engine extends EventEmitter {
  constructor(isPackaged) {
    super();
    this.bin = enginePath(isPackaged);
    this.proc = null;
    this.port = 10808;
    this.ready = false;
    this.timer = null;
    this.buf = '';
  }

  get running() { return !!this.proc; }

  start({ port = 10808, doh = true } = {}) {
    if (this.proc) return;
    if (!this.bin) { this.emit('error', new Error('Engine binary not found. Run: npm run build:core')); return; }
    this.port = port;
    const args = ['--port', String(port), '--strategy', 'split(sni)', '--auto'];
    if (doh) args.push('--doh');
    this.proc = spawn(this.bin, args, { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    this.proc.stdout.on('data', (d) => this._onData(d));
    this.proc.stderr.on('data', (d) => this.emit('log', String(d).trim()));
    this.proc.on('error', (e) => this.emit('error', e));
    this.proc.on('exit', (code) => {
      clearInterval(this.timer);
      this.proc = null;
      this.ready = false;
      this.emit('exit', code);
    });
  }

  _onData(d) {
    this.buf += d;
    let i;
    while ((i = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, i).trim();
      this.buf = this.buf.slice(i + 1);
      if (!line) continue;
      let ev;
      try { ev = JSON.parse(line); } catch { this.emit('log', line); continue; }
      if (ev.type === 'ready') {
        this.ready = true;
        this.timer = setInterval(() => this._send('STATS'), 1000);
      }
      this.emit(ev.type, ev);
      this.emit('event', ev);
    }
  }

  _send(cmd) {
    try { if (this.proc && this.proc.stdin.writable) this.proc.stdin.write(cmd + '\n'); } catch { /* engine is going away */ }
  }

  stop() {
    if (!this.proc) return Promise.resolve();
    return new Promise((resolve) => {
      const p = this.proc;
      const kill = setTimeout(() => { try { p.kill(); } catch { /* already gone */ } }, 1500);
      p.once('exit', () => { clearTimeout(kill); resolve(); });
      this._send('STOP');
    });
  }
}

module.exports = { Engine };
