'use strict';
const { app, BrowserWindow, Tray, Menu, ipcMain, nativeImage, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const { Engine } = require('./engine');
const { SysProxy } = require('./sysproxy');
const { DiscordMode } = require('./discord');
const { AdvancedEngine, isAdmin, explain } = require('./advanced');
const { DohForwarder } = require('./doh');
const diag = require('./diag');

if (!app.requestSingleInstanceLock()) app.quit();

// mode "system": every program on the PC, no per-app setup (packet layer, needs administrator).
// mode "proxy":  compatibility fallback for programs that honour the system proxy.
const DEFAULTS = { doh: true, autostart: false, startProtected: false, closeToTray: true, strong: false,
  theme: 'dark', accent: 'amber', mode: 'system', lang: 'auto' };
const ENUMS = { theme: ['dark', 'midnight', 'light'], accent: ['amber', 'violet', 'cyan', 'green', 'rose'],
  mode: ['system', 'proxy'], lang: ['auto', 'tr', 'en'] };
// Title bar buttons (Windows) follow the theme.
const CHROME = {
  dark: { bg: '#0b0d14', bar: '#0e1119', symbol: '#e8eaf2' },
  midnight: { bg: '#000000', bar: '#050507', symbol: '#e8eaf2' },
  light: { bg: '#f3f4f8', bar: '#e9ebf2', symbol: '#171a26' },
};
const ZERO = { conns_total: 0, conns_active: 0, bytes_up: 0, bytes_down: 0, desync: 0 };
const SYS_ZERO = { desynced: 0, dns: 0, quic: 0, since: 0 };
const TASK = 'AvexaLume';

let settings = { ...DEFAULTS };
let win = null;
let tray = null;
let quitting = false;
let discordSeen = false;
// note / fellBack: { k, a } = a key the window translates, and its values.
let state = { on: false, busy: false, active: 'none', stats: { ...ZERO }, sys: { ...SYS_ZERO }, rate: 0,
  sites: [], note: null, fellBack: null, diag: { running: false, results: [], at: 0 } };

const engine = new Engine(app.isPackaged);
const adv = new AdvancedEngine(app.isPackaged, path.join(app.getPath('userData'), 'task-stamp.json'));
const doh = new DohForwarder();
const admin = isAdmin();
let permReady = false;   // the one-time permission is in place (or the app is administrator itself)
let sysproxy;
let discord;
let timer = null;
let sample = { t: 0, v: 0 };
const userFile = (n) => path.join(app.getPath('userData'), n);

// A plain log next to the settings, so "it does not connect" can be looked into.
function log(msg) {
  try { fs.appendFileSync(userFile('lume.log'), new Date().toISOString() + ' ' + msg + '\n'); } catch { /* ignore */ }
}

function loadSettings() {
  let saved = {};
  try { saved = JSON.parse(fs.readFileSync(userFile('settings.json'), 'utf8')); } catch { /* first run */ }
  settings = { ...DEFAULTS };
  for (const k of Object.keys(DEFAULTS)) {
    if (!(k in saved)) continue;
    if (typeof DEFAULTS[k] === 'boolean') settings[k] = !!saved[k];
    else if (ENUMS[k] && ENUMS[k].includes(saved[k])) settings[k] = saved[k];
  }
}
function saveSettings() {
  try { fs.writeFileSync(userFile('settings.json'), JSON.stringify(settings, null, 2)); } catch { /* read-only profile */ }
}

function push() {
  if (win && !win.isDestroyed()) {
    win.webContents.send('lume:state', {
      ...state, settings, platform: process.platform, version: app.getVersion(), admin,
      sysReady: adv.available(), perm: permReady || admin, locale: app.getLocale(), doh: { answered: doh.answered },
      discord: { installed: discordSeen, active: !!(discord && discord.server), requests: discord ? discord.requests : 0, okAt: discord ? discord.okAt : 0 },
    });
  }
  if (tray) tray.setToolTip(state.on ? 'Avexa Lume: ' + (state.active === 'system' ? 'system-wide' : 'proxy') : 'Avexa Lume: off');
}
function say(k, a) { state.note = k ? { k, a: a || {} } : null; push(); }

function applyChrome() {
  const c = CHROME[settings.theme];
  if (!win || win.isDestroyed()) return;
  win.setBackgroundColor(c.bg);
  if (process.platform === 'win32') { try { win.setTitleBarOverlay({ color: c.bar, symbolColor: c.symbol, height: 40 }); } catch { /* old Electron */ } }
}

/* ---------- start / stop ---------- */

// Windows asks once; after that the engine starts without any prompt.
async function ensurePermission() {
  if (admin) return true;
  if (!(await adv.taskReady())) {
    say('permAsk');
    permReady = await adv.installTask();
  } else permReady = true;
  push();
  return permReady;
}

async function startSystem() {
  if (process.platform !== 'win32') return { ok: false, why: 'notWindows' };
  if (!adv.available()) return { ok: false, why: 'missingFiles' };
  if (!admin && !(await ensurePermission())) return { ok: false, why: 'needAdmin' };
  let dohPort = 0;
  if (settings.doh) {
    try { dohPort = await doh.start(); } catch (e) { log('doh: ' + e.message); }
  }
  adv.start({ dohPort, strong: settings.strong });
  const ok = await adv.waitReady(9000);
  if (!ok) {
    const e = adv.lastError || {};
    log('system mode failed: ' + JSON.stringify(e));
    await adv.stop(); doh.stop();
    return { ok: false, why: explain(e.code, e.win32), code: e.win32 || 0 };
  }
  state.sys = { ...SYS_ZERO, since: Date.now() };
  return { ok: true };
}

async function startProxy() {
  engine.once('error', (e) => say('engineMsg', { m: e.message }));
  engine.start({ port: 10808, doh: settings.doh });
  const ok = await new Promise((resolve) => {
    const t = setTimeout(() => resolve(false), 5000);
    engine.once('ready', () => { clearTimeout(t); resolve(true); });
    engine.once('exit', () => { clearTimeout(t); resolve(false); });
  });
  if (!ok) { await engine.stop(); return { ok: false, why: engine.bin ? 'engineFail' : 'engineMissing' }; }
  try { await sysproxy.enable(engine.port); } catch (e) { say('proxyFail', { m: e.message }); }
  // Discord's updater ignores the system proxy, so the relay is always on when Discord is installed.
  discordSeen = discord.installed();
  if (discordSeen && (await discord.start())) log('discord relay on port ' + discord.port);
  return { ok: true };
}

async function turnOn() {
  if (state.on || state.busy) return;
  state.busy = true; state.fellBack = null; state.note = null; push();
  let r = { ok: false };
  let active = 'none';
  if (settings.mode === 'system') {
    r = await startSystem();
    if (r.ok) active = 'system';
    else {
      // Never leave the person with nothing: fall back to the proxy mode and say why.
      log('system mode unavailable: ' + r.why + (r.code ? ' (' + r.code + ')' : ''));
      state.fellBack = { k: r.why, a: { code: r.code || 0 } };
    }
  }
  if (!r.ok) {
    const p = await startProxy();
    if (p.ok) { r = p; active = 'proxy'; } else { r = p; }
  }
  if (!r.ok) {
    state.busy = false; state.active = 'none';
    say(r.why || 'engineFail');
    return;
  }
  state.on = true; state.busy = false; state.active = active; state.sites = [];
  if (active === 'system') say('sysOn'); else if (!state.fellBack) say('proxyOn');
  startTick();
  push();
}

async function turnOff() {
  if (!state.on || state.busy) return;
  state.busy = true; push();
  stopTick();
  if (state.active === 'system') { await adv.stop(); doh.stop(); }
  else { discord.stop(); await sysproxy.disable(); await engine.stop(); }
  state.on = false; state.busy = false; state.active = 'none'; state.note = null; state.fellBack = null;
  state.stats = { ...ZERO }; state.sys = { ...SYS_ZERO }; state.rate = 0;
  push();
}

// Activity per second for the chart: bytes in proxy mode, DNS answers in system mode.
function startTick() {
  stopTick();
  sample = { t: Date.now(), v: 0 };
  timer = setInterval(() => {
    const now = Date.now();
    const v = state.active === 'system' ? doh.answered + state.sys.dns : (state.stats.bytes_up || 0) + (state.stats.bytes_down || 0);
    const dt = Math.max((now - sample.t) / 1000, 0.2);
    state.rate = v >= sample.v ? (v - sample.v) / dt : 0;
    sample = { t: now, v };
    push();
  }, 1000);
}
function stopTick() { if (timer) { clearInterval(timer); timer = null; } }

/* ---------- window, tray ---------- */

function createWindow() {
  const c = CHROME[settings.theme];
  win = new BrowserWindow({
    width: 1040, height: 700, minWidth: 900, minHeight: 600,
    backgroundColor: c.bg, title: 'Avexa Lume', autoHideMenuBar: true, show: false,
    ...(process.platform === 'win32' ? { titleBarStyle: 'hidden', titleBarOverlay: { color: c.bar, symbolColor: c.symbol, height: 40 } } : {}),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, '..', 'ui', 'index.html'));
  win.once('ready-to-show', () => { if (!process.argv.includes('--hidden')) win.show(); });
  win.on('close', (e) => {
    if (!quitting && settings.closeToTray) { e.preventDefault(); win.hide(); } else quitting = true;
  });
  win.webContents.on('did-finish-load', () => { discordSeen = discord.installed(); push(); });
  win.on('focus', () => { const now = discord.installed(); if (now !== discordSeen) { discordSeen = now; push(); } });
}

function createTray() {
  const icon = path.join(__dirname, '..', 'ui', 'assets', 'icon.png');
  tray = new Tray(fs.existsSync(icon) ? icon : nativeImage.createEmpty());
  tray.setToolTip('Avexa Lume');
  tray.on('click', () => { if (win) { win.show(); win.focus(); } });
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Avexa Lume', click: () => { win.show(); win.focus(); } },
    { label: 'On / Off', click: () => (state.on ? turnOff() : turnOn()) },
    { type: 'separator' },
    { label: 'Quit', click: () => { quitting = true; app.quit(); } },
  ]));
}

/* ---------- engine events ---------- */

engine.on('stats', (s) => { state.stats = s; });
engine.on('log', (m) => log('engine: ' + m));
engine.on('bypass', (e) => {
  if (!state.sites.find((x) => x.host === e.host)) { state.sites.unshift({ host: e.host, ok: true }); state.sites = state.sites.slice(0, 8); push(); }
});
engine.on('blocked', (e) => {
  state.sites = [{ host: e.host, ok: false }, ...state.sites.filter((x) => x.host !== e.host)].slice(0, 8);
  say('addrBlocked');
});
engine.on('exit', () => {
  if (state.on && !state.busy && state.active === 'proxy') {
    state.on = false; state.active = 'none'; stopTick(); discord.stop();
    sysproxy.disable().then(() => say('engineStopped'));
  }
});

adv.on('log', (m) => log('adv: ' + m));
adv.on('event', (e) => { if (e.type !== 'raw_stats') log('adv: ' + JSON.stringify(e)); });
adv.on('raw_stats', (e) => {
  state.sys.desynced = e.desynced || 0;
  state.sys.dns = e.dns_answered || 0;
  state.sys.quic = e.quic_dropped || 0;
});
adv.on('exit', () => {
  if (state.on && !state.busy && state.active === 'system') {
    state.on = false; state.active = 'none'; stopTick(); doh.stop();
    say('engineStopped');
  }
});
doh.on('log', (m) => log(m));

/* ---------- admin, autostart ---------- */

function setAutostart(on) {
  if (process.platform !== 'win32') return;
  app.setLoginItemSettings({ openAtLogin: on, path: process.env.PORTABLE_EXECUTABLE_FILE || process.execPath, args: ['--hidden'] });
}

/* ---------- IPC ---------- */

ipcMain.handle('lume:toggle', () => (state.on ? turnOff() : turnOn()));
ipcMain.handle('lume:set', async (_e, key, value) => {
  if (!(key in DEFAULTS)) return;
  if (typeof DEFAULTS[key] === 'boolean') settings[key] = !!value;
  else if (ENUMS[key] && ENUMS[key].includes(value)) settings[key] = value;
  else return;
  saveSettings();
  if (key === 'autostart') setAutostart(settings.autostart);
  if (key === 'theme') applyChrome();
  if (['doh', 'mode', 'strong'].includes(key) && state.on) { await turnOff(); await turnOn(); }
  push();
});
ipcMain.handle('lume:restart-discord', async () => {
  const did = await discord.restart();
  say(did ? 'discordRestarted' : 'discordNotRunning');
});
ipcMain.handle('lume:open-log', () => {
  const f = userFile('lume.log');
  if (fs.existsSync(f)) shell.showItemInFolder(f); else shell.openPath(app.getPath('userData'));
});
ipcMain.handle('lume:admin', async () => {
  if (state.busy) return;
  const ok = await ensurePermission();
  if (!ok) return say('adminCancelled');
  if (!state.on) await turnOn(); else { await turnOff(); await turnOn(); }
});
ipcMain.handle('lume:diag', async () => {
  if (state.diag.running) return;
  state.diag = { running: true, results: [], at: 0 }; push();
  const results = await diag.runAll((r) => { state.diag.results = [...state.diag.results.filter((x) => x.id !== r.id), r]; push(); });
  log('diag: ' + results.map((r) => `${r.host}=${r.ok ? 'ok' : r.stage + ':' + r.error}`).join(' '));
  state.diag = { running: false, results, at: Date.now() };
  push();
});

app.whenReady().then(() => {
  sysproxy = new SysProxy(app.getPath('userData'));
  discord = new DiscordMode(() => (engine.ready ? engine.port : null), (m) => log(m));
  loadSettings();
  // A crash or kill last time may have left our proxy setting behind.
  sysproxy.disableSync();
  adv.taskReady().then((r) => { permReady = r; push(); });
  createWindow();
  createTray();
  if (settings.startProtected) turnOn();
});

app.on('second-instance', () => { if (win) { win.show(); win.focus(); } });
app.on('before-quit', () => { quitting = true; });
app.on('will-quit', (e) => {
  if (!state.on && !engine.running && !adv.running) return;
  e.preventDefault();
  Promise.resolve().then(async () => {
    stopTick(); discord.stop(); doh.stop();
    await adv.stop(); await sysproxy.disable(); await engine.stop();
    state.on = false; app.exit(0);
  });
});
process.on('exit', () => { try { sysproxy.disableSync(); } catch { /* best effort */ } });
