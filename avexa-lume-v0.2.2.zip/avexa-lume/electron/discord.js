'use strict';
// Discord app mode. Discord's own updater ignores the system proxy, so it sits
// on "Checking for updates" / "Update failed". We run a small local relay and
// point Discord's NEW_UPDATE_ENDPOINT at it. The relay repeats each request to
// Discord over TLS 1.3 through the engine's SOCKS5 port, so the DPI can read
// neither the name nor the certificate.
//
// What the updater asks for: a manifest (JSON) from updates.discord.com whose
// links point at Discord's CDN. Those links are rewritten to come back here,
// otherwise the downloads would go around us and fail.
const http = require('http');
const net = require('net');
const tls = require('tls');
const fs = require('fs');
const path = require('path');
const { execFile, spawn } = require('child_process');

const KEY = 'NEW_UPDATE_ENDPOINT';
const OURS = /^http:\/\/127\.0\.0\.1:\d+\/$/;
const DEFAULT_HOST = 'updates.discord.com';
const PREFIX = '/__h/';
const PORTS = [10809, 18809, 28809];
const IDLE_MS = 30000;

const DOMAINS = ['discord.com', 'discord.gg', 'discord.co', 'discord.media', 'discord.new', 'discord.gift',
  'discord.gifts', 'discord.dev', 'discord.design', 'discord.store', 'discord.tools', 'discordapp.com',
  'discordapp.net', 'discordcdn.com', 'discordstatus.com', 'discordsays.com', 'dis.gd'];

const BUILDS = [
  { dir: 'discord', local: 'Discord', exe: 'Discord.exe' },
  { dir: 'discordptb', local: 'DiscordPTB', exe: 'DiscordPTB.exe' },
  { dir: 'discordcanary', local: 'DiscordCanary', exe: 'DiscordCanary.exe' },
  { dir: 'discorddevelopment', local: 'DiscordDevelopment', exe: 'DiscordDevelopment.exe' },
];

const HOP = ['connection', 'keep-alive', 'proxy-connection', 'proxy-authorization', 'te', 'trailer', 'transfer-encoding', 'upgrade'];

function isDiscordHost(host) {
  const h = String(host || '').toLowerCase().replace(/\.$/, '');
  if (!/^[a-z0-9.-]{1,253}$/.test(h)) return false;
  return DOMAINS.some((d) => h === d || h.endsWith('.' + d));
}

// Absolute https links on Discord's own domains -> this relay.
function rewriteUrls(text, base) {
  return text.replace(/https:\/\/([a-z0-9.-]+)(?=[/"'?\s\\]|$)/gi, (m, host) =>
    (isDiscordHost(host) ? base + PREFIX + host.toLowerCase() : m));
}

// SOCKS5 CONNECT by name, so the engine resolves it over encrypted DNS.
function socksConnect(socksPort, host, port) {
  return new Promise((resolve, reject) => {
    const s = net.connect({ host: '127.0.0.1', port: socksPort });
    let stage = 0;
    let buf = Buffer.alloc(0);
    const fail = (e) => { s.destroy(); reject(e); };
    s.setTimeout(15000, () => fail(new Error('SOCKS timeout')));
    s.once('error', fail);
    s.once('close', () => reject(new Error('SOCKS closed')));
    s.once('connect', () => s.write(Buffer.from([5, 1, 0])));
    const onData = (d) => {
      buf = Buffer.concat([buf, d]);
      if (stage === 0) {
        if (buf.length < 2) return;
        if (buf[0] !== 5 || buf[1] !== 0) return fail(new Error('SOCKS auth refused'));
        buf = buf.subarray(2);
        stage = 1;
        const h = Buffer.from(host);
        s.write(Buffer.concat([Buffer.from([5, 1, 0, 3, h.length]), h, Buffer.from([port >> 8, port & 255])]));
      }
      if (stage === 1) {
        if (buf.length < 5) return;
        if (buf[1] !== 0) return fail(new Error('SOCKS connect failed (' + buf[1] + ')'));
        const need = buf[3] === 1 ? 10 : buf[3] === 4 ? 22 : 7 + buf[4];
        if (buf.length < need) return;
        s.removeListener('data', onData);
        s.removeListener('error', fail);
        s.removeAllListeners('close');
        s.setTimeout(0);
        if (buf.length > need) s.unshift(buf.subarray(need));
        resolve(s);
      }
    };
    s.on('data', onData);
  });
}

class DiscordMode {
  constructor(getSocksPort, log) {
    this.getSocksPort = getSocksPort;
    this.log = log || (() => {});
    this.server = null;
    this.port = 0;
    this.pool = null;
    this.poolPort = null;
    this.touched = [];
    this.requests = 0;
    this.okAt = 0;
    this.warned = new Map();
  }

  _dirs() {
    const base = process.platform === 'win32' ? process.env.APPDATA
      : process.platform === 'darwin' ? path.join(process.env.HOME || '', 'Library', 'Application Support') : null;
    if (!base) return [];
    return BUILDS.map((b) => ({ ...b, settings: path.join(base, b.dir, 'settings.json') }))
      .filter((b) => fs.existsSync(path.dirname(b.settings)));
  }

  installed() { return this._dirs().length > 0; }

  _warn(key, msg) {
    const now = Date.now();
    if (now - (this.warned.get(key) || 0) < 30 * 60 * 1000) return;
    this.warned.set(key, now);
    this.log(msg);
  }

  async _connect(host) {
    const socksPort = this.getSocksPort();
    if (!socksPort) throw new Error('the engine is not running');
    const raw = await socksConnect(socksPort, host, 443);
    // TLS 1.3 is the point: it keeps the server's certificate encrypted.
    const sock = tls.connect({ socket: raw, servername: host, minVersion: 'TLSv1.3', ALPNProtocols: ['http/1.1'] });
    sock.setTimeout(IDLE_MS, () => sock.destroy(new Error('timed out')));
    return sock;
  }

  // Connections to Discord kept open between requests: the updater asks for a
  // manifest and then many modules one after another.
  _agent() {
    const port = this.getSocksPort() || null;
    if (this.pool && this.poolPort === port) return this.pool;
    if (this.pool) { try { this.pool.destroy(); } catch { /* gone */ } }
    const agent = new http.Agent({ keepAlive: true, maxSockets: 6, maxFreeSockets: 4, timeout: IDLE_MS, scheduling: 'lifo' });
    agent.createConnection = (opts, cb) => { this._connect(opts.host).then((s) => cb(null, s), (e) => cb(e)); };
    this.pool = agent;
    this.poolPort = port;
    return agent;
  }

  _handle(req, res) {
    const self = '127.0.0.1:' + this.port;
    const hostHdr = String(req.headers.host || '').toLowerCase();
    // Only this machine, only under its own name (a web page cannot rebind a name onto it).
    if (hostHdr !== self && hostHdr !== 'localhost:' + this.port) { res.writeHead(403); return res.end(); }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }

    let host = DEFAULT_HOST;
    let p = req.url || '/';
    if (p.startsWith(PREFIX)) {
      const rest = p.slice(PREFIX.length);
      const i = rest.search(/[/?]/);
      host = (i < 0 ? rest : rest.slice(0, i)).toLowerCase();
      p = i < 0 ? '/' : rest.slice(i);
      if (!p.startsWith('/')) p = '/' + p;
    }
    if (!isDiscordHost(host)) { res.writeHead(403); return res.end(); }

    this.requests++;
    const base = 'http://' + self;
    const headers = { ...req.headers, host };
    for (const h of HOP) delete headers[h];
    headers['accept-encoding'] = 'identity'; // so JSON links can be rewritten

    // One more try on a new connection when it fails before any answer: the
    // updater shows "Update failed" at the first error, so it should not see it.
    const attempt = (n) => {
      if (res.destroyed) return;
      let answered = false;
      const up = http.request({ agent: this._agent(), host, port: 443, method: req.method, path: p, headers }, (ur) => {
        answered = true;
        const h = { ...ur.headers };
        for (const k of HOP) delete h[k];
        if (h.location && /^https:\/\//i.test(h.location)) h.location = rewriteUrls(h.location, base);
        if (ur.statusCode < 400) this.okAt = Date.now();
        ur.on('error', () => res.destroy());
        if (/json/i.test(String(h['content-type'] || '')) && req.method === 'GET') {
          const chunks = [];
          let size = 0;
          ur.on('data', (c) => { size += c.length; if (size > 8 * 1024 * 1024) { ur.destroy(); res.destroy(); } else chunks.push(c); });
          ur.on('end', () => {
            const body = Buffer.from(rewriteUrls(Buffer.concat(chunks).toString('utf8'), base));
            delete h['content-encoding'];
            h['content-length'] = String(body.length);
            res.writeHead(ur.statusCode, h);
            res.end(body);
          });
          return;
        }
        res.writeHead(ur.statusCode, h);
        ur.pipe(res);
      });
      up.on('error', (e) => {
        if (!answered && n < 3 && !res.headersSent && !res.destroyed) return attempt(n + 1);
        this._warn((answered ? 'failed:' : 'unreachable:') + host, 'Discord relay: ' + host + p.split('?')[0] + ' failed (' + e.message + ')');
        if (!res.headersSent) { res.writeHead(502); res.end(); } else res.destroy();
      });
      res.on('close', () => { if (!res.writableFinished) up.destroy(); });
      up.end();
    };
    attempt(1);
  }

  _listen(port) {
    return new Promise((resolve, reject) => {
      const srv = http.createServer((q, r) => this._handle(q, r));
      srv.on('clientError', (e, sock) => { try { sock.destroy(); } catch { /* gone */ } });
      srv.once('error', reject);
      srv.listen(port, '127.0.0.1', () => {
        srv.removeListener('error', reject);
        srv.on('error', () => {});
        this.server = srv;
        this.port = srv.address().port;
        resolve();
      });
    });
  }

  async start() {
    if (this.server) return true;
    for (const p of [...PORTS, 0]) {
      try { await this._listen(p); break; } catch { /* try the next port */ }
    }
    if (!this.server) return false;
    const endpoint = `http://127.0.0.1:${this.port}/`;
    for (const b of this._dirs()) {
      try {
        let j = {};
        try { j = JSON.parse(fs.readFileSync(b.settings, 'utf8')); } catch { /* new file */ }
        // An endpoint the user set themselves is never touched.
        if (j[KEY] && !OURS.test(String(j[KEY]))) continue;
        if (j[KEY] !== endpoint) { j[KEY] = endpoint; fs.writeFileSync(b.settings, JSON.stringify(j, null, 2)); }
        this.touched.push(b.settings);
      } catch (e) { this.log('Discord settings: ' + e.message); }
    }
    return true;
  }

  stop() {
    for (const f of this.touched) {
      try {
        const j = JSON.parse(fs.readFileSync(f, 'utf8'));
        if (OURS.test(String(j[KEY] || ''))) { delete j[KEY]; fs.writeFileSync(f, JSON.stringify(j, null, 2)); }
      } catch { /* file gone */ }
    }
    this.touched = [];
    if (this.pool) { try { this.pool.destroy(); } catch { /* gone */ } this.pool = null; }
    if (this.server) { try { this.server.close(); this.server.closeAllConnections?.(); } catch { /* closed */ } this.server = null; }
  }

  // Discord reads the endpoint once at start, so a Discord that is already
  // open (or stuck on its update screen) has to be started again.
  restart() {
    if (process.platform !== 'win32') return Promise.resolve(false);
    const local = process.env.LOCALAPPDATA || '';
    const runs = (exe) => new Promise((r) => execFile('tasklist', ['/FI', 'IMAGENAME eq ' + exe, '/NH'], { windowsHide: true }, (e, out) => r(!e && String(out).toLowerCase().includes(exe.toLowerCase()))));
    const kill = (exe) => new Promise((r) => execFile('taskkill', ['/F', '/T', '/IM', exe], { windowsHide: true }, () => r()));
    return (async () => {
      let did = false;
      for (const b of this._dirs()) {
        if (!(await runs(b.exe))) continue;
        await kill(b.exe);
        await new Promise((r) => setTimeout(r, 1200));
        const update = path.join(local, b.local, 'Update.exe');
        if (fs.existsSync(update)) { spawn(update, ['--processStart', b.exe], { detached: true, stdio: 'ignore' }).unref(); did = true; }
      }
      return did;
    })();
  }
}

module.exports = { DiscordMode, isDiscordHost, rewriteUrls };
