'use strict';
// System-wide mode. Runs avexa-core-adv.exe (packet layer, WinDivert), which sees every
// program's traffic, so no program has to know about a proxy.
//
// It needs administrator rights, but the app does NOT: the first time, Windows asks once
// (UAC) and the engine registers a scheduled task that may start it with those rights.
// From then on the app writes a small request file and starts the task, no prompt
// (core/src/advtask.h). If the app itself already runs as administrator it starts the
// engine directly.
const { spawn, execFileSync, execFile } = require('child_process');
const { EventEmitter } = require('events');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const os = require('os');

function isAdmin() {
  if (process.platform !== 'win32') return false;
  try { execFileSync('fltmc', [], { windowsHide: true, stdio: 'ignore' }); return true; } catch { return false; }
}

function advPath(isPackaged) {
  const exe = 'avexa-core-adv.exe';
  const list = isPackaged
    ? [path.join(process.resourcesPath, 'core', exe)]
    : [path.join(__dirname, '..', 'core', 'bin', exe)];
  return list.find((p) => fs.existsSync(p)) || null;
}

const userName = () => process.env.USERNAME || os.userInfo().username;
const taskName = () => `Avexa Advanced mode (${userName()})`;
const userDir = () => path.join(process.env.LOCALAPPDATA || os.homedir(), 'Avexa', 'advanced');

// <Common Files>\Avexa\advanced, where the engine's copies and its status logs live.
function adminDir() {
  let base = '';
  try {
    const out = execFileSync('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion', '/v', 'CommonFilesDir'], { windowsHide: true }).toString();
    const m = out.match(/CommonFilesDir\s+REG_SZ\s+(.+)/);
    if (m) base = m[1].trim();
  } catch { /* use the environment below */ }
  if (!base) base = process.env.CommonProgramW6432 || process.env.CommonProgramFiles || 'C:\\Program Files\\Common Files';
  return path.join(base, 'Avexa', 'advanced');
}

// The request the engine reads when the task starts it. Only a few options are accepted
// (advtask_parse): numbers, words, no file names. See core/src/advtask.c.
function buildRequest(id, { pid, dohPort = 0, strong = false }) {
  const lines = ['avexa-advanced 1', 'id ' + id, '--advanced', '--parent-pid', String(pid)];
  if (dohPort) lines.push('--dns-gate', String(dohPort));
  if (strong) lines.push('--tlsrec', '1');
  return lines.join('\n') + '\n';
}

// What a WinDivert failure means for a person, by Windows' own error code.
function explain(code, win32) {
  if (code === 'taskrun') return 'taskFail';
  if (code === 'windivert_load') return win32 === 126 ? 'missingDll' : 'avBlocked';
  if (code === 'windivert_open') {
    if (win32 === 5) return 'needAdmin';
    if (win32 === 2 || win32 === 3) return 'missingSys';
    if (win32 === 577 || win32 === 1275) return 'driverSignature';
    return 'avBlocked';
  }
  return 'engineFail';
}

const run = (cmd, args) => new Promise((resolve) => execFile(cmd, args, { windowsHide: true }, (err, out) => resolve({ err, out: String(out || '') })));

class AdvancedEngine extends EventEmitter {
  constructor(isPackaged, stampFile) {
    super();
    this.bin = advPath(isPackaged);
    this.stampFile = stampFile;      // remembers which engine build the task was set up for
    this.proc = null;                // direct start (app is administrator)
    this.task = null;                // start by the task: { id, status, stop, offset, tail, alive, pid }
    this.ready = false;
    this.buf = '';
    this.lastError = null;
  }

  get running() { return !!this.proc || !!this.task; }

  available() {
    if (!this.bin) return false;
    const dir = path.dirname(this.bin);
    return fs.existsSync(path.join(dir, 'WinDivert.dll')) && fs.existsSync(path.join(dir, 'WinDivert64.sys'));
  }

  _stamp() {
    try { return crypto.createHash('sha256').update(fs.readFileSync(this.bin)).digest('hex'); } catch { return ''; }
  }

  // Is the one-time permission in place for this very build of the engine?
  async taskReady() {
    if (!this.available()) return false;
    const q = await run('schtasks', ['/Query', '/TN', taskName()]);
    if (q.err) return false;
    try { return JSON.parse(fs.readFileSync(this.stampFile, 'utf8')).stamp === this._stamp(); } catch { return false; }
  }

  // Windows asks once (UAC). Resolves true when the task exists afterwards.
  async installTask() {
    if (!this.available()) return false;
    const exe = this.bin.replace(/'/g, "''");
    const ps = `Start-Process -FilePath '${exe}' -ArgumentList '--task-install-only','"${userName().replace(/['"]/g, '')}"' -Verb RunAs -Wait -WindowStyle Hidden`;
    const r = await run('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps]);
    if (r.err) { this.emit('log', 'task install refused: ' + r.err.message); return false; }
    const q = await run('schtasks', ['/Query', '/TN', taskName()]);
    if (q.err) return false;
    try { fs.writeFileSync(this.stampFile, JSON.stringify({ stamp: this._stamp() })); } catch { /* not fatal */ }
    return true;
  }

  start({ dohPort = 0, strong = false } = {}) {
    if (this.running) return;
    this.lastError = null; this.ready = false; this.buf = '';
    if (isAdmin()) this._startDirect({ dohPort, strong });
    else this._startTask({ dohPort, strong });
  }

  _startDirect({ dohPort, strong }) {
    const args = ['--advanced', '--parent-pid', String(process.pid)];
    if (dohPort) args.push('--dns-gate', String(dohPort));
    if (strong) args.push('--tlsrec', '1');
    this.proc = spawn(this.bin, args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true, cwd: path.dirname(this.bin) });
    this.proc.stdout.on('data', (d) => this._data(d));
    this.proc.stderr.on('data', (d) => this._data(d));
    this.proc.on('error', (e) => { this.lastError = { code: 'spawn', msg: e.message }; this.emit('error', e); });
    this.proc.on('exit', (code) => { this.proc = null; this._ended(code); });
  }

  _startTask({ dohPort, strong }) {
    const id = crypto.randomBytes(16).toString('hex');
    const t = { id, status: path.join(adminDir(), 'run', id + '.log'), stop: path.join(userDir(), id + '.stop'), offset: 0, tail: null, alive: null, pid: 0 };
    this.task = t;
    try {
      fs.mkdirSync(userDir(), { recursive: true });
      fs.writeFileSync(path.join(userDir(), 'request'), buildRequest(id, { pid: process.pid, dohPort, strong }));
    } catch (e) { this.lastError = { code: 'taskrun', msg: e.message }; this.task = null; return this.emit('exit', 1); }
    t.tail = setInterval(() => this._readStatus(), 300);
    this.on('task', (e) => { t.pid = e.pid; });
    t.alive = setInterval(() => {
      if (!t.pid) return;
      try { process.kill(t.pid, 0); } catch (e) { if (e.code === 'ESRCH') this._ended(0); }   // EPERM: it runs, we just may not touch it
    }, 1000);
    execFile('schtasks', ['/Run', '/TN', taskName()], { windowsHide: true }, (err) => {
      if (err) { this.lastError = { code: 'taskrun', msg: err.message }; this._ended(1); }
    });
  }

  _readStatus() {
    const t = this.task;
    if (!t) return;
    let fd;
    try {
      const size = fs.statSync(t.status).size;
      if (size <= t.offset) return;
      fd = fs.openSync(t.status, 'r');
      const b = Buffer.alloc(Math.min(size - t.offset, 1 << 20));
      const n = fs.readSync(fd, b, 0, b.length, t.offset);
      t.offset += n;
      this._data(b.subarray(0, n).toString('utf8'));
    } catch { /* not created yet */ } finally { if (fd !== undefined) try { fs.closeSync(fd); } catch { /* closed */ } }
  }

  _ended(code) {
    const t = this.task;
    if (t) { clearInterval(t.tail); clearInterval(t.alive); this.task = null; this.removeAllListeners('task'); }
    const was = this.ready;
    this.ready = false;
    if (was || t || this.lastError || code !== undefined) this.emit('exit', code);
  }

  _data(d) {
    this.buf += d;
    let i;
    while ((i = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, i).trim();
      this.buf = this.buf.slice(i + 1);
      if (!line) continue;
      let ev;
      try { ev = JSON.parse(line); } catch { this.emit('log', line); continue; }
      if (ev.type === 'raw_ready') this.ready = true;
      if (ev.type === 'error') this.lastError = ev;
      this.emit(ev.type, ev);
      this.emit('event', ev);
      if (ev.type === 'stopped' && this.task) setTimeout(() => this._ended(0), 200);
    }
  }

  // Resolves true when the packet hook is open, false when it failed or timed out.
  waitReady(ms = 9000) {
    return new Promise((resolve) => {
      if (this.ready) return resolve(true);
      const done = (v) => { clearTimeout(t); this.removeListener('raw_ready', onReady); this.removeListener('exit', onExit); resolve(v); };
      const onReady = () => done(true);
      const onExit = () => done(false);
      const t = setTimeout(() => done(false), ms);
      this.once('raw_ready', onReady);
      this.once('exit', onExit);
    });
  }

  stop() {
    if (this.proc) {
      return new Promise((resolve) => {
        const p = this.proc;
        const hard = setTimeout(() => execFile('taskkill', ['/F', '/T', '/PID', String(p.pid)], { windowsHide: true }, () => {}), 2500);
        p.once('exit', () => { clearTimeout(hard); resolve(); });
        try { p.kill(); } catch { /* already gone */ }
      });
    }
    const t = this.task;
    if (!t) return Promise.resolve();
    return new Promise((resolve) => {
      try { fs.writeFileSync(t.stop, ''); } catch { /* the engine also ends when this app does */ }
      const hard = setTimeout(() => { run('schtasks', ['/End', '/TN', taskName()]); setTimeout(() => { this._ended(0); resolve(); }, 800); }, 3000);
      this.once('exit', () => { clearTimeout(hard); try { fs.unlinkSync(t.stop); } catch { /* gone */ } resolve(); });
    });
  }
}

module.exports = { AdvancedEngine, isAdmin, explain, buildRequest };
