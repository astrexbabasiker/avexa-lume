'use strict';
// Points Windows at Lume's local proxy through a PAC file and always puts the
// previous setting back. Other platforms are not wired up yet.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execFile, execFileSync } = require('child_process');

const KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings';
const PAC_PORTS = Array.from({ length: 20 }, (_, i) => 10840 + i);

function reg(args) {
  return new Promise((resolve) => execFile('reg', args, { windowsHide: true }, (e, out) => resolve(e ? null : out)));
}
function regSync(args) {
  try { return execFileSync('reg', args, { windowsHide: true }).toString(); } catch { return null; }
}
function readValue(name) {
  return reg(['query', KEY, '/v', name]).then((out) => {
    if (!out) return null;
    const m = out.match(new RegExp(name + '\\s+(REG_\\w+)\\s+(.*)'));
    return m ? { type: m[1], data: m[2].trim() } : null;
  });
}

// Tell WinINET that settings changed so running programs pick it up now.
function refresh() {
  const ps = "$s='[DllImport(\"wininet.dll\")] public static extern bool InternetSetOption(IntPtr h,int o,IntPtr b,int l);';" +
    "$t=Add-Type -MemberDefinition $s -Name W -Namespace L -PassThru;" +
    "[void]$t::InternetSetOption([IntPtr]::Zero,39,[IntPtr]::Zero,0);[void]$t::InternetSetOption([IntPtr]::Zero,37,[IntPtr]::Zero,0)";
  return new Promise((r) => execFile('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true }, () => r()));
}

class SysProxy {
  constructor(userDir) {
    this.supported = process.platform === 'win32';
    this.backupFile = path.join(userDir, 'proxy-backup.json');
    this.server = null;
    this.active = false;
  }

  _pac(socksPort) {
    return 'function FindProxyForURL(url, host) {\n' +
      '  if (isPlainHostName(host) || host === "localhost" || shExpMatch(host, "*.local") ||\n' +
      '      isInNet(host, "10.0.0.0", "255.0.0.0") || isInNet(host, "172.16.0.0", "255.240.0.0") ||\n' +
      '      isInNet(host, "192.168.0.0", "255.255.0.0") || isInNet(host, "127.0.0.0", "255.0.0.0")) return "DIRECT";\n' +
      '  return "SOCKS5 127.0.0.1:' + socksPort + '; DIRECT";\n}\n';
  }

  async _serve(socksPort) {
    const body = this._pac(socksPort);
    for (const port of PAC_PORTS) {
      const ok = await new Promise((resolve) => {
        const s = http.createServer((req, res) => {
          res.writeHead(200, { 'Content-Type': 'application/x-ns-proxy-autoconfig', 'Cache-Control': 'no-store' });
          res.end(body);
        });
        s.once('error', () => resolve(null));
        s.listen(port, '127.0.0.1', () => resolve(s));
      });
      if (ok) { this.server = ok; return port; }
    }
    throw new Error('No free port for the proxy config server');
  }

  async enable(socksPort) {
    if (!this.supported || this.active) return { ok: this.active };
    const pacPort = await this._serve(socksPort);
    // Back up the user's own setting once, before the first change.
    if (!fs.existsSync(this.backupFile)) {
      const prev = { AutoConfigURL: await readValue('AutoConfigURL'), AutoDetect: await readValue('AutoDetect') };
      fs.writeFileSync(this.backupFile, JSON.stringify(prev));
    }
    await reg(['add', KEY, '/v', 'AutoConfigURL', '/t', 'REG_SZ', '/d', `http://127.0.0.1:${pacPort}/lume.pac`, '/f']);
    await refresh();
    this.active = true;
    return { ok: true, pacPort };
  }

  async disable() {
    if (this.server) { try { this.server.close(); } catch { /* closed */ } this.server = null; }
    if (!this.supported) return;
    let prev = {};
    try { prev = JSON.parse(fs.readFileSync(this.backupFile, 'utf8')); } catch { /* no backup: nothing to restore */ }
    if (fs.existsSync(this.backupFile)) {
      if (prev.AutoConfigURL) await reg(['add', KEY, '/v', 'AutoConfigURL', '/t', prev.AutoConfigURL.type, '/d', prev.AutoConfigURL.data, '/f']);
      else await reg(['delete', KEY, '/v', 'AutoConfigURL', '/f']);
      try { fs.unlinkSync(this.backupFile); } catch { /* already gone */ }
      await refresh();
    }
    this.active = false;
  }

  // Last-resort restore for process exit, where nothing async can run.
  disableSync() {
    if (!this.supported || !fs.existsSync(this.backupFile)) return;
    let prev = {};
    try { prev = JSON.parse(fs.readFileSync(this.backupFile, 'utf8')); } catch { /* ignore */ }
    if (prev.AutoConfigURL) regSync(['add', KEY, '/v', 'AutoConfigURL', '/t', prev.AutoConfigURL.type, '/d', prev.AutoConfigURL.data, '/f']);
    else regSync(['delete', KEY, '/v', 'AutoConfigURL', '/f']);
    try { fs.unlinkSync(this.backupFile); } catch { /* ignore */ }
  }
}

module.exports = { SysProxy };
